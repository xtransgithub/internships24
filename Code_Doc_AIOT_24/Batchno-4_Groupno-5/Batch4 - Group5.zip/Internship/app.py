from flask import Flask, render_template, request, jsonify
from backend import process_air_quality, trigger_buzzer  # Import the backend functions
import RPi.GPIO as GPIO
import time

app = Flask(__name__)

# GPIO setup for buzzer
BUZZER_PIN = 38
GPIO.setmode(GPIO.BOARD)
GPIO.setup(BUZZER_PIN, GPIO.OUT)

@app.route("/")
def home():
    return render_template("index.html")  # Your frontend HTML page

@app.route("/check_air_quality", methods=["POST"])
def check_air_quality():
    datetime_input = request.form.get("datetime")
    if not datetime_input:
        return jsonify({"status": "error", "message": "Invalid input!"}), 400

    # Call the backend function to process air quality based on the datetime
    results = process_air_quality(datetime_input)

    if "error" in results:
        return jsonify({"status": "error", "message": results["error"]}), 400

    # Initialize a list to store which pollutants exceed the threshold
    exceeded_pollutants = []

    # Check each pollutant to see if it exceeds the threshold
    if results["filtered_data"]:
        data = results["filtered_data"][0]
        if data["pm10"] > 155:
            exceeded_pollutants.append("PM10")
        if data["pm2_5"] > 35.5:
            exceeded_pollutants.append("PM2.5")
        if data["carbon_monoxide"] > 9.5:
            exceeded_pollutants.append("Carbon Monoxide")
        if data["nitrogen_dioxide"] > 100:
            exceeded_pollutants.append("Nitrogen Dioxide")
        if data["sulphur_dioxide"] > 75:
            exceeded_pollutants.append("Sulphur Dioxide")
        if data["ozone"] > 70:
            exceeded_pollutants.append("Ozone")

    # If any pollutants exceeded the threshold, trigger the buzzer and alert message
    if exceeded_pollutants:
        alert_message = f"Alert! The following pollutants exceeded safe levels: {', '.join(exceeded_pollutants)}."
        print(alert_message)  # Print the alert message to the console

        # Trigger the buzzer
        trigger_buzzer()

        # Return the alert message along with the air quality data
        return jsonify({"status": "success", "message": alert_message, "results": results})

    # If no pollutants exceeded thresholds, return the results normally
    return jsonify({"status": "success", "results": results})

@app.route('/trigger_buzzer', methods=['POST'])
def manual_buzzer_trigger():
    data = request.get_json()  # Get any data sent from frontend
    message = data.get('message', 'Pollution alert triggered!')
    print(message)

    # Trigger buzzer manually
    trigger_buzzer()

    return jsonify({"status": "success", "message": "Buzzer triggered!"})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)