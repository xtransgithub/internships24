import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008
import Adafruit_DHT
import openmeteo_requests
import requests_cache
import pandas as pd
from retry_requests import retry
from datetime import datetime, timedelta
import RPi.GPIO as GPIO
import time

# Suppress warnings about channel already in use
GPIO.setwarnings(False)

# SPI setup for gas sensor
SPI_PORT = 0
SPI_DEVICE = 0
mcp = Adafruit_MCP3008.MCP3008(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))

# Setup DHT11 sensor
DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 4

# Thresholds for air quality pollutants
UNHEALTHY_THRESHOLDS = {
    "pm10": 155,
    "pm2_5": 35.5,
    "carbon_monoxide": 9.5,
    "nitrogen_dioxide": 100,
    "sulphur_dioxide": 75,
    "ozone": 70,
}
GAS_SENSOR_THRESHOLD = 300
TEMPERATURE_THRESHOLD = 35
HUMIDITY_THRESHOLD = 80

def process_air_quality(datetime_input):
    """Processes air quality data and returns results."""
    try:
        # Setup Open-Meteo API with caching and retry
        cache_session = requests_cache.CachedSession('.cache', expire_after=3600)
        retry_session = retry(cache_session, retries=5, backoff_factor=0.2)
        openmeteo = openmeteo_requests.Client(session=retry_session)

        # Fetch air quality data from the Open-Meteo API
        url = "https://air-quality-api.open-meteo.com/v1/air-quality"
        params = {
            "latitude": 12.9719,
            "longitude": 77.5937,
            "hourly": ["pm10", "pm2_5", "carbon_monoxide", "nitrogen_dioxide", "sulphur_dioxide", "ozone"],
            "timezone": "Asia/Singapore",
        }
        responses = openmeteo.weather_api(url, params=params)
        response = responses[0]
        hourly = response.Hourly()

        # Process hourly air quality data
        hourly_data = {
            "date": pd.date_range(
                start=pd.to_datetime(hourly.Time(), unit="s", utc=True),
                end=pd.to_datetime(hourly.TimeEnd(), unit="s", utc=True),
                freq=pd.Timedelta(seconds=hourly.Interval()),
                inclusive="left",
            ),
            "pm10": hourly.Variables(0).ValuesAsNumpy(),
            "pm2_5": hourly.Variables(1).ValuesAsNumpy(),
            "carbon_monoxide": hourly.Variables(2).ValuesAsNumpy(),
            "nitrogen_dioxide": hourly.Variables(3).ValuesAsNumpy(),
            "sulphur_dioxide": hourly.Variables(4).ValuesAsNumpy(),
            "ozone": hourly.Variables(5).ValuesAsNumpy(),
        }

        hourly_dataframe = pd.DataFrame(data=hourly_data)

        # Parse datetime input to match with the API's hourly data
        input_time = datetime.strptime(datetime_input, "%Y-%m-%d %H:%M")
        rounded_time = input_time.replace(minute=0, second=0, microsecond=0)
        rounded_time_str = rounded_time.strftime('%Y-%m-%d %H:%M:%S')

        # Filter the data for the specific datetime
        filtered_data = hourly_dataframe[
            hourly_dataframe["date"].dt.strftime('%Y-%m-%d %H:%M:%S') == rounded_time_str
        ]

        if not filtered_data.empty:
            # Read sensor values
            gas_value = mcp.read_adc(0)  # Read gas sensor value
            humidity, temperature = Adafruit_DHT.read_retry(DHT_SENSOR, DHT_PIN)  # Read humidity and temperature

            # Prepare the results with filtered data and sensor readings
            results = {
                "filtered_data": filtered_data.to_dict(orient="records"),
                "gas_value": gas_value,
                "temperature": temperature,
                "humidity": humidity,
            }
            return results
        else:
            return {"error": "No data available for the given time."}

    except Exception as e:
        return {"error": str(e)}

def trigger_buzzer():
    """Triggers the buzzer to sound."""
    GPIO.output(38, GPIO.HIGH)  # Turn the buzzer on
    time.sleep(1)  # Wait for 1 second
    GPIO.output(38, GPIO.LOW)  # Turn the buzzer off