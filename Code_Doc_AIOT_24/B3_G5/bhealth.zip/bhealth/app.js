// Function to fetch sensor data from the server
async function fetchSensorData() {
    try {
        const response = await fetch('http://192.168.14.62:5000/sensor-data');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        console.log('Fetched sensor data:', data); // Debugging
        return data;
    } catch (error) {
        console.error('Error fetching sensor data:', error);
        return null;
    }
}

// Function to download health data as CSV
function downloadHealthData() {
    const downloadUrl = 'http://192.168.14.62:5000/download-data';
    window.open(downloadUrl, '_blank');
}

// Add event listener to the download button
document.getElementById("download-button").addEventListener("click", downloadHealthData);

// Initialize history traces and layouts for the charts
const heartRateHistoryDiv = document.getElementById("heart-rate-history");
const bloodPressureHistoryDiv = document.getElementById("blood-pressure-history");
const temperatureHistoryDiv = document.getElementById("temperature-history");

const heartRateTrace = { x: [], y: [], name: "Heart Rate", mode: "lines+markers", type: "line" };
const bloodPressureTrace = { x: [], y: [], name: "Blood Pressure", mode: "lines+markers", type: "line" };
const temperatureTrace = { x: [], y: [], name: "Temperature", mode: "lines+markers", type: "line" };

const heartRateLayout = { autosize: false, title: { text: "Heart Rate" }, font: { size: 14, color: "#7f7f7f" }, colorway: ["#B22222"], width: 450, height: 260, margin: { t: 50, b: 30, l: 50, r: 20 } };
const bloodPressureLayout = { autosize: false, title: { text: "Blood Pressure" }, font: { size: 14, color: "#7f7f7f" }, colorway: ["#00008B"], width: 450, height: 260, margin: { t: 50, b: 30, l: 50, r: 20 } };
const temperatureLayout = { autosize: false, title: { text: "Temperature" }, font: { size: 14, color: "#7f7f7f" }, colorway: ["#FF4500"], width: 450, height: 260, margin: { t: 50, b: 30, l: 50, r: 20 } };

const config = {
    displayModeBar: true,
    displaylogo: false,
    modeBarButtonsToRemove: ['zoom2d', 'pan2d', 'select2d', 'lasso2d', 'resetScale2d', 'hoverClosestCartesian', 'hoverCompareCartesian'],
    toImageButtonOptions: { format: 'png', filename: 'chart_snapshot', height: 500, width: 800 }
};

// Initialize the charts
Plotly.newPlot(heartRateHistoryDiv, [heartRateTrace], heartRateLayout, config);
Plotly.newPlot(bloodPressureHistoryDiv, [bloodPressureTrace], bloodPressureLayout, config);
Plotly.newPlot(temperatureHistoryDiv, [temperatureTrace], temperatureLayout, config);

const MAX_GRAPH_POINTS = 12;
let heartRateXArray = [], heartRateYArray = [];
let bloodPressureXArray = [], bloodPressureYArray = [];
let temperatureXArray = [], temperatureYArray = [];
let ctr = 0;

// Function to update sensor readings
async function updateSensorReadings() {
    const sensorData = await fetchSensorData();
    if (sensorData) {
        const { heartRate, bloodPressure, temperature } = sensorData;

        updateBoxes(heartRate, bloodPressure, temperature);
        updateCharts(heartRateHistoryDiv, heartRateXArray, heartRateYArray, parseFloat(heartRate));
        updateCharts(bloodPressureHistoryDiv, bloodPressureXArray, bloodPressureYArray, bloodPressure);
        updateCharts(temperatureHistoryDiv, temperatureXArray, temperatureYArray, parseFloat(temperature));

        updateRecommendations(heartRate, bloodPressure, temperature); // Update recommendations
    } else {
        console.error('No sensor data available or an error occurred.');
    }
}

// Function to update text boxes for heart rate, blood pressure, and temperature
function updateBoxes(heartRate, bloodPressure, temperature) {
    document.getElementById("heart-rate").innerHTML = `${heartRate} BPM`;
    document.getElementById("blood-pressure").innerHTML = `${bloodPressure}`;
    document.getElementById("temperature").innerHTML = `${temperature} °C`;
}

// Function to update history charts
function updateCharts(chartDiv, xArray, yArray, sensorRead) {
    if (xArray.length >= MAX_GRAPH_POINTS) xArray.shift();
    if (yArray.length >= MAX_GRAPH_POINTS) yArray.shift();

    xArray.push(ctr++);
    yArray.push(sensorRead);
    Plotly.update(chartDiv, { x: [xArray], y: [yArray] });
}

// Function to generate recommendations based on sensor data
function generateRecommendations(heartRate, bloodPressure, temperature) {
    let recommendations = [];

    if (heartRate < 60) recommendations.push("Heart rate is low. Consider consulting a doctor.");
    else if (heartRate > 100) recommendations.push("Heart rate is high. Try to rest and monitor.");
    else recommendations.push("Heart rate is normal.");

    const [systolic, diastolic] = bloodPressure.split('/').map(Number);
    if (systolic < 90 || diastolic < 60) recommendations.push("Low blood pressure detected. Stay hydrated and avoid sudden movements.");
    else if (systolic > 140 || diastolic > 90) recommendations.push("High blood pressure detected. Limit salt intake and relax.");
    else recommendations.push("Blood pressure is within normal range.");

    if (temperature < 36.1) recommendations.push("Body temperature is low. Keep warm and monitor.");
    else if (temperature > 37.5) recommendations.push("High temperature detected. Stay hydrated and rest.");
    else recommendations.push("Body temperature is normal.");

    return recommendations;
}

// Function to update recommendations
function updateRecommendations(heartRate, bloodPressure, temperature) {
    const recommendations = generateRecommendations(heartRate, bloodPressure, temperature);
    const recommendationsList = document.getElementById("recommendations-list");
    recommendationsList.innerHTML = "";

    recommendations.forEach(rec => {
        const listItem = document.createElement("li");
        listItem.textContent = rec;
        recommendationsList.appendChild(listItem);
    });
}

// Periodically update sensor readings every 15 seconds
setInterval(updateSensorReadings, 5000);
