import time
import random
import logging
from flask import Flask, jsonify, request
from flask_cors import CORS
from twilio.rest import Client  # Import Twilio client to send SMS
import RPi.GPIO as gpio  # Import RPi.GPIO to control the buzzer

# Set up logging to console
logging.basicConfig(level=logging.DEBUG)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable Cross-Origin Resource Sharing to allow communication with React

# Twilio Credentials (replace with your actual credentials)
TWILIO_ACCOUNT_SID = 'AC1db621d79e08256be8c764824f511382'
TWILIO_AUTH_TOKEN = '3606dacc2c5877563ef67bcbeda958b7'
TWILIO_PHONE_NUMBER = '+17753059858'
TO_PHONE_NUMBER = '+919608910785'  # The phone number to receive messages

# Initialize Twilio client
client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)

# GPIO Setup for Buzzer
gpio.setwarnings(False)
gpio.setmode(gpio.BOARD)
buzzer_pin = 38  # Buzzer connected to GPIO 38
gpio.setup(buzzer_pin, gpio.OUT)

# Normal and high ranges for weather parameters
normal_ranges = {
    "temperature": (60, 85),  # Fahrenheit
    "humidity": (30, 60),  # Percentage
    "wind_speed": (0, 15),  # mph
    "wind_degree": (0, 360),  # Degrees
}

high_ranges = {
    "temperature": (85, 110),  # Fahrenheit
    "humidity": (60, 100),  # Percentage
    "wind_speed": (15, 30),  # mph
    "wind_degree": (0, 360),  # Degrees
}

# Possible weather conditions
weather_conditions = [
    "Clear", "Cloudy", "Rainy", "Stormy", "Snowy", "Foggy", "Windy"
]

def send_sms(message):
    """Send an SMS using Twilio"""
    message = client.messages.create(
        body=message,
        from_=TWILIO_PHONE_NUMBER,
        to=TO_PHONE_NUMBER
    )
    logging.info(f"Sent message: {message.sid}")

def activate_buzzer():
    """Activate buzzer for alert"""
    gpio.output(buzzer_pin, 1)  # Turn ON the buzzer
    logging.info("Buzzer ON")
    time.sleep(2)  # Keep the buzzer ON for 2 seconds
    gpio.output(buzzer_pin, 0)  # Turn OFF the buzzer
    logging.info("Buzzer OFF")

def generate_weather_readings(range_type='normal'):
    """Generate random weather readings based on a specified range (normal or high)."""
    def get_reading(parameter, range_type):
        if range_type == 'high':
            return random.randint(*high_ranges[parameter])
        else:
            return random.randint(*normal_ranges[parameter])

    weather_data = {
        "temperature": get_reading("temperature", range_type),
        "humidity": get_reading("humidity", range_type),
        "wind_speed": random.randint(0, 30),  # Wind speed can vary
        "wind_direction": random.choice(["N", "NE", "E", "SE", "S", "SW", "W", "NW"]),
        "wind_degree": random.randint(0, 360),  # Wind degrees
        "weather_description": random.choice(weather_conditions)  # Weather condition
    }

    # Send SMS and activate buzzer if weather is "Rainy", "Windy", or "Stormy"
    if weather_data['weather_description'] in ['Rainy', 'Windy', 'Stormy']:
        send_sms(f"Alert: The weather today is {weather_data['weather_description']}. Be prepared!")
        activate_buzzer()  # Trigger buzzer alert

    # Log the generated weather data
    logging.debug(f"Weather Data: {weather_data}")

    return weather_data


@app.route('/weather-data', methods=['GET'])
def weather_data():
    """Endpoint to return simulated weather data."""
    range_type = request.args.get('range', 'normal')  # Allow user to specify 'normal' or 'high' range
    data = generate_weather_readings(range_type)
    time.sleep(2)  # Simulate delay
    return jsonify(data)


@app.route('/7-day-forecast', methods=['GET'])
def seven_day_forecast():
    """Endpoint to return simulated 7-day weather forecast data."""
    forecast_data = []
    range_type = request.args.get('range', 'normal')  # Allow user to specify 'normal' or 'high' range
   
    for i in range(7):  # Generate data for 7 days
        day_data = generate_weather_readings(range_type)
        forecast_data.append({
            "day": f"Day {i+1}",  # Day 1, Day 2, ..., Day 7
            "temperature": day_data['temperature'],
            "weather_condition": day_data['weather_description']
        })
       
    time.sleep(2)  # Simulate delay
    return jsonify(forecast_data)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

