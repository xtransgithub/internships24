from flask import Flask, render_template, jsonify
import requests
import RPi.GPIO as GPIO
import time
import threading

app = Flask(__name__)

# Constants for APIs
API_KEY_LOCATION = "8ae3af5378754e4d8716ed38462d88e1"  # OpenCage API Key
API_KEY_WEATHER = "0115690c425cb36ec0ad4996ebd1690c"   # OpenWeatherMap API Key

# Locations with latitude, longitude, and LED pin
locations = [
    {"name": "Street 1", "lat": 12.9716, "lon": 77.5946, "led_pin": 5, "status": "OFF", "weather": "N/A", "city": ""},
    {"name": "Street 2", "lat": 12.9716, "lon": 77.5946, "led_pin": 3, "status": "OFF", "weather": "N/A", "city": ""},
    {"name": "Street 3", "lat": 12.9716, "lon": 77.5946, "led_pin": 12, "status": "OFF", "weather": "N/A", "city": ""}
]

# GPIO pin for light sensor
LIGHT_SENSOR_PIN = 33

# Cache for weather data
weather_cache = {}
CACHE_INTERVAL = 600  # 10 minutes (600 seconds)

# GPIO Setup
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(LIGHT_SENSOR_PIN, GPIO.IN)
for location in locations:
    GPIO.setup(location["led_pin"], GPIO.OUT, initial=GPIO.LOW)

def get_city_name(lat, lon):
    """
    Get the city name from latitude and longitude using OpenCage API.
    """
    try:
        url = f"https://api.opencagedata.com/geocode/v1/json?q={lat}+{lon}&key={API_KEY_LOCATION}"
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            if data['results']:
                return data['results'][0]['components'].get('city', "City Not Found")
    except Exception as e:
        print(f"Error fetching city name: {e}")
    return "Unknown"

def fetch_weather_data(city_name):
    """
    Fetch weather data for the given city name using OpenWeatherMap API.
    """
    try:
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={API_KEY_WEATHER}"
        response = requests.get(url)
        if response.status_code == 200:
            return response.json()
    except Exception as e:
        print(f"Error fetching weather data: {e}")
    return None

def update_led_states():
    """
    Update the state of LEDs based on light and weather conditions.
    """
    while True:
        light_state = GPIO.input(LIGHT_SENSOR_PIN)  # Check light sensor state
        for location in locations:
            current_time = time.time()
            if location["city"] not in weather_cache or (current_time - weather_cache[location["city"]]['timestamp']) > CACHE_INTERVAL:
                weather_data = fetch_weather_data(location["city"])
                if weather_data:
                    weather_cache[location["city"]] = {
                        "data": weather_data,
                        "timestamp": current_time
                    }
                    location["weather"] = weather_data['weather'][0]['main']
                else:
                    location["weather"] = "N/A"
                    continue
            else:
                weather_data = weather_cache[location["city"]]['data']
                location["weather"] = weather_data['weather'][0]['main']

            # Control LED
            if light_state == 1:  # Darkness detected
                if location["weather"] in ['Clear', 'Clouds']:
                    GPIO.output(location["led_pin"], GPIO.HIGH)
                    location["status"] = "ON"
                else:
                    GPIO.output(location["led_pin"], GPIO.LOW)
                    location["status"] = "OFF"
            else:
                GPIO.output(location["led_pin"], GPIO.LOW)
                location["status"] = "OFF"

        time.sleep(10)

def initialize_city_names():
    """
    Fetch and set the city names for all locations at startup.
    """
    for location in locations:
        city_name = get_city_name(location["lat"], location["lon"])
        location["city"] = city_name if city_name != "Unknown" else "City Not Found"

@app.route("/")
def home():
    """
    Render the homepage with the status of LEDs and weather.
    """
    return render_template("index.html", locations=locations)

@app.route("/api/status")
def api_status():
    """
    Provide an API endpoint for current LED and weather statuses.
    """
    return jsonify({"locations": locations})

if __name__ == "__main__":
    initialize_city_names()
    threading.Thread(target=update_led_states, daemon=True).start()
    app.run(host="0.0.0.0", port=5000)
