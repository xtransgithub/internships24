const CHANNEL_ID = '2768902'; // Replace with your channel ID
const READ_API_KEY = 'G389D4CF7ACIQQJ3'; // Replace with your Read API Key
const RESULTS = 10; // Number of results to fetch
const REFRESH_INTERVAL = 10000; // Fetch new data every 10 seconds (in milliseconds)
const NOTIFICATION_INTERVAL = 300000; // Max 1 notification every 5 minutes (in milliseconds)

const url = `https://api.thingspeak.com/channels/${CHANNEL_ID}/feeds.json?api_key=${READ_API_KEY}&results=${RESULTS}`;

let lastNotificationTime = 0; // To track the last notification time

async function fetchThingSpeakData() {
    try {
        const response = await fetch(url);
        const data = await response.json();
        const feeds = data.feeds;

        // Reference to the table body
        const tableBody = document.getElementById('data-table');
        tableBody.innerHTML = ''; // Clear any existing rows

        // Populate table with data
        feeds.forEach(feed => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${new Date(feed.created_at).toLocaleString()}</td> <!-- Format time -->
                <td>${feed.field1 || 'N/A'}</td>
                <td>${feed.field2 || 'N/A'}</td>
                <td>${feed.field3 || 'N/A'}</td>
                <td>${feed.field4 || 'N/A'}</td>
            `;
            tableBody.appendChild(row);

            // Check for notification conditions
            const gas = parseFloat(feed.field4);
            const distance = parseFloat(feed.field3);
            const currentTime = Date.now();

            if (
                !isNaN(gas) &&
                !isNaN(distance) &&
                gas < 340 &&
                distance < 10 &&
                currentTime - lastNotificationTime >= NOTIFICATION_INTERVAL
            ) {
                showNotification(`Alert! Gas value is ${distance} and distance is ${gas}.`);
                lastNotificationTime = currentTime; // Update last notification time
            }
        });
    } catch (error) {
        console.error('Error fetching data from ThingSpeak:', error);
    }
}

// Function to show notifications
function showNotification(message) {
    const notificationDiv = document.getElementById('notification');
    notificationDiv.innerText = message;
    notificationDiv.style.display = 'block';

    // Hide notification after 10 seconds
    setTimeout(() => {
        notificationDiv.style.display = 'none';
    }, 10000);
}

// Fetch data initially when the page loads
fetchThingSpeakData();

// Set an interval to refresh data every REFRESH_INTERVAL milliseconds
setInterval(fetchThingSpeakData, REFRESH_INTERVAL);



