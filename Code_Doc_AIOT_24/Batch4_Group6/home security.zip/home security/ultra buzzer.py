# @Auth Xtrans Solutions Pvt. Ltd.
# Ultrasonic Sensor with LED and Buzzer Alert

import RPi.GPIO as GPIO
import time

# GPIO setup
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

# Ultrasonic Sensor Pins
TRIG = 19
ECHO = 26

# Buzzer and LED Pins
BUZZER = 20
LED = 2

# GPIO pin configurations
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
GPIO.setup(BUZZER, GPIO.OUT)
GPIO.setup(LED, GPIO.OUT)

# Initialize LED and Buzzer to OFF
GPIO.output(TRIG, False)
GPIO.output(LED, GPIO.LOW)  # Ensure LED is OFF initially
GPIO.output(BUZZER, GPIO.LOW)  # Ensure Buzzer is OFF initially

print("Ultrasonic sensor measuring distance...")

try:
    while True:
        # Ensure trigger is low for a brief moment
        GPIO.output(TRIG, False)
        time.sleep(0.5)

        # Send trigger pulse
        GPIO.output(TRIG, True)
        time.sleep(0.00001)
        GPIO.output(TRIG, False)

        # Measure the echo pulse duration
        while GPIO.input(ECHO) == 0:
            pulse_start = time.time()
        while GPIO.input(ECHO) == 1:
            pulse_end = time.time()

        # Calculate distance
        pulse_duration = pulse_end - pulse_start
        distance = round(pulse_duration * 17150, 2)

        print(f"Distance: {distance} cm")

        # Object detection logic
        if 2 < distance < 50:  # Threshold for object detection
            print("Object detected! Activating LED and Buzzer.")
            GPIO.output(BUZZER, GPIO.HIGH)  # Turn Buzzer ON
            GPIO.output(LED, GPIO.HIGH)  # Turn LED ON
            time.sleep(0.5)  # Alert duration
            GPIO.output(BUZZER, GPIO.LOW)  # Turn Buzzer OFF
            GPIO.output(LED, GPIO.LOW)  # Turn LED OFF after detection
        else:
            # Ensure LED and Buzzer remain OFF if no object is detected
            GPIO.output(LED, GPIO.LOW)
            GPIO.output(BUZZER, GPIO.LOW)

except KeyboardInterrupt:
    print("Measurement stopped by user")
    GPIO.cleanup()  
