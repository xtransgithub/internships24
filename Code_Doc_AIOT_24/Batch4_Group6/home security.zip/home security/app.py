from flask import Flask, render_template
import Adafruit_DHT
import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008
import requests
import time
import RPi.GPIO as gpio

# Initialize Flask app
app = Flask(__name__)

# ThingSpeak Configuration
THINGSPEAK_URL = "https://api.thingspeak.com/update"
API_KEY = "LGL73HM4QVP6BCTW"  # Replace with your actual Write API key

# Sensor Setup
sensor = Adafruit_DHT.DHT11
pin = 4  # DHT11 GPIO pin

# Gas sensor setup
SPI_PORT = 0
SPI_DEVICE = 0
mcp = Adafruit_MCP3008.MCP3008(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))

# Ultrasonic sensor setup
TRIG = 19
ECHO = 26

# Buzzer and LED setup
BUZZER = 20
LED = 2

# GPIO setup
gpio.setwarnings(False)
gpio.setmode(gpio.BCM)

# Setup pins
gpio.setup(TRIG, gpio.OUT)
gpio.setup(ECHO, gpio.IN)
gpio.setup(BUZZER, gpio.OUT)
gpio.setup(LED, gpio.OUT)

# Gas sensor threshold
threshold = 340  # Adjust based on calibration

# Initialize outputs
gpio.output(TRIG, False)
gpio.output(BUZZER, gpio.LOW)
gpio.output(LED, gpio.LOW)


# Function to read gas sensor
def read_gas_sensor():
    value1 = mcp.read_adc(0)  # Read ADC value from channel 0
    print("Gas Sensor Value:", value1)
    return value1


# Function to measure distance using ultrasonic sensor
def measure_distance():
    gpio.output(TRIG, True)
    time.sleep(0.00001)
    gpio.output(TRIG, False)

    while gpio.input(ECHO) == 0:
        pulse_start = time.time()
    while gpio.input(ECHO) == 1:
        pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start
    distance = round(pulse_duration * 17150, 2)
    print(f"Distance: {distance} cm")
    return distance


# Function to send data to ThingSpeak
def send_to_thingspeak(humidity, temperature, gas_value, distance):
    payload = {
        "api_key": API_KEY,
        "field1": humidity,
        "field2": temperature,
        "field3": gas_value,
        "field4": distance
    }
    response = requests.post(THINGSPEAK_URL, data=payload)
    if response.status_code == 200:
        print(f"Data sent to ThingSpeak: {response.text}")
    else:
        print(f"Failed to send data to ThingSpeak: {response.status_code}")


# Function to fetch sensor data
def get_sensor_data():
    humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)
    if humidity is None or temperature is None:
        humidity = temperature = 0  # Fallback values

    gas_value = read_gas_sensor()
    distance = measure_distance()

    # Send data to ThingSpeak
    send_to_thingspeak(humidity, temperature, gas_value, distance)

    # Handle gas sensor alerts
    if gas_value < threshold:
        gpio.output(BUZZER, gpio.HIGH)
        gpio.output(LED, gpio.HIGH)
        print("Gas Alert: Buzzer ON")
    else:
        gpio.output(BUZZER, gpio.LOW)
        gpio.output(LED, gpio.LOW)

    # Handle ultrasonic sensor alerts
    if 2 < distance < 50:
        gpio.output(BUZZER, gpio.HIGH)
        gpio.output(LED, gpio.HIGH)
        print("Object Detected: Activating LED and Buzzer")
        time.sleep(0.5)
        gpio.output(BUZZER, gpio.LOW)
        gpio.output(LED, gpio.LOW)

    return humidity, temperature, gas_value, distance


# Flask route to display sensor data
@app.route('/')
def home():
    humidity, temperature, gas_value, distance = get_sensor_data()
    return render_template(
        'table.html',
        humidity=humidity,
        temperature=temperature,
        gas_value=gas_value,
        distance=distance
    )


# Cleanup GPIO on exit
@app.route('/shutdown')
def shutdown():
    gpio.cleanup()
    return "GPIO cleaned up. Goodbye!"


# Start Flask app
if __name__ == '__main__':
    try:
        app.run(debug=True, host='0.0.0.0')
    except KeyboardInterrupt:
        print("Exiting gracefully")
        gpio.cleanup()
