# Required libraries for ThingSpeak integration
import requests
import Adafruit_DHT
import os
from flask import Flask, request
import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008
import time
import RPi.GPIO as gpio


# Initialize Flask app
app = Flask(__name__)

# ThingSpeak Configuration
THINGSPEAK_URL = "https://api.thingspeak.com/update"
API_KEY = "LGL73HM4QVP6BCTW"  # Replace with your actual Write API key
sensor = Adafruit_DHT.DHT11
pin = 4

# Gas sensor setup
SPI_PORT = 0
SPI_DEVICE = 0
mcp = Adafruit_MCP3008.MCP3008(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))

# Ultrasonic sensor setup
TRIG = 19
ECHO = 26

# Buzzer and LED setup
BUZZER = 20
LED = 2

# GPIO setup
gpio.setwarnings(False)
gpio.setmode(gpio.BCM)

# Gas sensor threshold
threshold = 340  # Adjust the threshold value based on your sensor calibration

# Setup Ultrasonic Sensor pins
gpio.setup(TRIG, gpio.OUT)
gpio.setup(ECHO, gpio.IN)

# Setup Buzzer and LED pins
gpio.setup(BUZZER, gpio.OUT)
gpio.setup(LED, gpio.OUT)

# Initialize all outputs to OFF
gpio.output(TRIG, False)
gpio.output(BUZZER, gpio.LOW)
gpio.output(LED, gpio.LOW)
# Function to send data to ThingSpeak

def read_gas_sensor():
    value1 = mcp.read_adc(0)  # Read ADC value from channel 0
    print("Raw Gas Value: ", value1)  # Print the raw ADC value
    return value1

# Function to measure distance using ultrasonic sensor
def measure_distance():
    # Send trigger pulse
    gpio.output(TRIG, True)
    time.sleep(0.00001)
    gpio.output(TRIG, False)

    # Measure pulse duration
    while gpio.input(ECHO) == 0:
        pulse_start = time.time()
    while gpio.input(ECHO) == 1:
        pulse_end = time.time()

    # Calculate distance
    pulse_duration = pulse_end - pulse_start
    distance = round(pulse_duration * 17150, 2)
    print(f"Distance: {distance} cm")
    return distance
def send_to_thingspeak(humidity, temperature, gas_value, distance):
    payload = {
        "api_key": API_KEY,
        "field1": humidity,      # Humidity data
        "field2": temperature,   # Temperature data
        "field3": gas_value,     # Gas sensor value
        "field4": distance       # Ultrasonic sensor distance
    }
    response = requests.post(THINGSPEAK_URL, data=payload)
    if response.status_code == 200:
        print(f"Data sent to ThingSpeak: {response.text}")
    else:
        print(f"Failed to send data to ThingSpeak: {response.status_code}")


# Flask route to home page
@app.route('/')
def home():
    return render_template('table.html')

# Main loop with ThingSpeak integration
try:
    while True:
        # Read humidity and temperature
        humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)
        if humidity is not None and temperature is not None:
            print(f"Humidity = {humidity}")
            print(f"Temperature = {temperature}")
        else:
            print("Failed to retrieve temperature and humidity data.")

        # Read gas sensor value
        gas_value = read_gas_sensor()

        # Measure distance using ultrasonic sensor
        distance = measure_distance()

        # Send data to ThingSpeak
        send_to_thingspeak(humidity, temperature, gas_value, distance)

        # Check gas sensor condition
        if gas_value < threshold:
            gpio.output(BUZZER, gpio.HIGH)  # Turn buzzer ON
            gpio.output(LED, gpio.HIGH)  # Turn LED ON
            print("Buzzer ON - Gas level is below threshold!")
        else:
            gpio.output(BUZZER, gpio.LOW)  # Turn buzzer OFF
            gpio.output(LED, gpio.LOW)  # Turn LED OFF
            print("Buzzer OFF - Gas level is within safe range.")

        # Check ultrasonic sensor condition
        if distance < 10:  # Threshold for object detection
            print("Object detected! Activating LED and Buzzer.")
            gpio.output(BUZZER, gpio.HIGH)  # Turn Buzzer ON
            gpio.output(LED, gpio.HIGH)  # Turn LED ON
            time.sleep(0.5)  # Alert duration
            gpio.output(BUZZER, gpio.LOW)  # Turn Buzzer OFF
            gpio.output(LED, gpio.LOW)  # Turn LED OFF after detection
        else:
            # Ensure LED and Buzzer remain OFF if no object is detected
            gpio.output(BUZZER, gpio.LOW)
            gpio.output(LED, gpio.LOW)

        time.sleep(15)  

except KeyboardInterrupt:
    print("Measurement stopped by user")
    gpio.cleanup()  # Clean up GPIO settings before exit
