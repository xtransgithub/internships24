import os
import RPi.GPIO as GPIO
import time
import requests
from flask import Flask, request

# Flask app setup
app = Flask(__name__)

# Ultrasonic Sensor setup
TRIG = 19
ECHO = 26
GPIO.setmode(GPIO.BCM)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

# Directory to save received images
SAVE_FOLDER = "received_images"
os.makedirs(SAVE_FOLDER, exist_ok=True)  # Create folder if it doesn't exist


# Function to calculate distance
def get_distance():
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)
    start_time = time.time()
    stop_time = time.time()

    while GPIO.input(ECHO) == 0:
        start_time = time.time()

    while GPIO.input(ECHO) == 1:
        stop_time = time.time()

    return ((stop_time - start_time) * 34300) / 2  # Distance in cm


# Flask route to receive the image
@app.route("/receive_image", methods=["POST"])
def receive_image():
    image = request.files['image']

    # Generate a unique filename
    timestamp = int(time.time())
    filename = f"image_{timestamp}.jpg"
    save_path = os.path.join(SAVE_FOLDER, filename)

    # Save the image
    image.save(save_path)
    print(f"Image received and saved as {save_path}")
    return "Image received successfully!"


# Main function to monitor distance and send trigger
def monitor_distance():
    while True:
        distance = get_distance()
        if distance < 10:
            print("Distance less than 10 cm! Sending trigger...")
            try:
                # Send trigger to the laptop Flask server
                response = requests.post("http://192.168.14.8:5000/trigger", json={"trigger": True})
                print(f"Trigger response: {response.status_code}")
            except Exception as e:
                print(f"Error sending trigger: {e}")
            time.sleep(1)  # Avoid rapid triggers


# Start Flask app and distance monitoring in parallel
if __name__ == "__main__":
    import threading

    # Run Flask app in a separate thread
    flask_thread = threading.Thread(target=lambda: app.run(host="0.0.0.0", port=5000))
    flask_thread.daemon = True  # Ensure Flask stops when the main thread stops
    flask_thread.start()

    # Start monitoring distance
    try:
        monitor_distance()
    except KeyboardInterrupt:
        print("Stopping...")
        GPIO.cleanup()
