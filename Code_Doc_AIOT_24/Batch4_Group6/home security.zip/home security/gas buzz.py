# @Auth Xtrans Solutions Pvt. Ltd.
# Program to test Gas sensor and Buzzer
# Connect Gas sensor from RM22 to RM12
# Connect Buzzer from RM9 to RM17

import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008
import time
import RPi.GPIO as gpio

# Gas sensor setup
SPI_PORT   = 0
SPI_DEVICE = 0
mcp = Adafruit_MCP3008.MCP3008(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))

# Buzzer setup
gpio.setwarnings(False)
gpio.setmode(gpio.BCM)  # Set GPIO to BCM mode
gpio.setup(20, gpio.OUT)  # Pin 12 (BCM) for buzzer

LED = 2
gpio.setup(LED, gpio.OUT) 
gpio.output(LED, gpio.LOW)
# Define threshold for gas sensor
threshold = 40  # Adjust the threshold value based on your sensor calibration

while True:
    # Read gas sensor value
    value1 = mcp.read_adc(0)
    print("Gas Value: ", value1)

    # Check if the gas level is less than the threshold (below 40)
    if value1 < threshold:
        gpio.output(20, 1)  # Turn buzzer ON (BCM pin 12)
        gpio.output(LED, gpio.HIGH)
        print("Buzzer ON - Gas level is below threshold!")
    else:
        gpio.output(20, 0)  # Turn buzzer OFF (BCM pin 12)
        gpio.output(LED, gpio.LOW)
        print("Buzzer OFF - Gas level is within safe range.")
    
    time.sleep(1)  # Delay before reading the sensor again
    
    
    
    
    
