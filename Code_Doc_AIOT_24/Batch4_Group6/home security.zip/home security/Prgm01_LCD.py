# @Auth Xtrans Solutions Pvt. Ltd.
# Combined Program to read DHT11 sensor data and display it on an LCD

import time
import Adafruit_DHT
import RPi.GPIO as GPIO

# DHT11 Sensor Setup
sensor = Adafruit_DHT.DHT11
dht_pin = 4  # GPIO pin connected to the DHT11 data pin

# LCD Setup
LCD_RS = 15
LCD_E = 12
LCD_D4 = 23
LCD_D5 = 21
LCD_D6 = 19
LCD_D7 = 24

# Define some device constants
LCD_WIDTH = 16    # Maximum characters per line
LCD_CHR = True
LCD_CMD = False

LCD_LINE_1 = 0x80  # LCD RAM address for the 1st line
LCD_LINE_2 = 0xC0  # LCD RAM address for the 2nd line

# Timing constants
E_PULSE = 0.0005
E_DELAY = 0.0005

def lcd_init():
    """Initialize the LCD display."""
    lcd_byte(0x33, LCD_CMD)  # 110011 Initialize
    lcd_byte(0x32, LCD_CMD)  # 110010 Initialize
    lcd_byte(0x06, LCD_CMD)  # Cursor move direction
    lcd_byte(0x0C, LCD_CMD)  # Display On, Cursor Off, Blink Off
    lcd_byte(0x28, LCD_CMD)  # Data length, number of lines, font size
    lcd_byte(0x01, LCD_CMD)  # Clear display
    time.sleep(E_DELAY)

def lcd_byte(bits, mode):
    """Send byte to data pins."""
    GPIO.output(LCD_RS, mode)  # RS

    # High bits
    GPIO.output(LCD_D4, bits & 0x10 == 0x10)
    GPIO.output(LCD_D5, bits & 0x20 == 0x20)
    GPIO.output(LCD_D6, bits & 0x40 == 0x40)
    GPIO.output(LCD_D7, bits & 0x80 == 0x80)

    # Toggle 'Enable' pin
    lcd_toggle_enable()

    # Low bits
    GPIO.output(LCD_D4, bits & 0x01 == 0x01)
    GPIO.output(LCD_D5, bits & 0x02 == 0x02)
    GPIO.output(LCD_D6, bits & 0x04 == 0x04)
    GPIO.output(LCD_D7, bits & 0x08 == 0x08)

    # Toggle 'Enable' pin
    lcd_toggle_enable()

def lcd_toggle_enable():
    """Toggle enable pin."""
    time.sleep(E_DELAY)
    GPIO.output(LCD_E, True)
    time.sleep(E_PULSE)
    GPIO.output(LCD_E, False)
    time.sleep(E_DELAY)

def lcd_string(message, line):
    """Send string to display."""
    message = message.ljust(LCD_WIDTH, " ")
    lcd_byte(line, LCD_CMD)
    for i in range(LCD_WIDTH):
        lcd_byte(ord(message[i]), LCD_CHR)

def main():
    """Main program block."""
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD)  # Use BOARD pin numbering

    # Setup LCD pins as outputs
    GPIO.setup(LCD_E, GPIO.OUT)
    GPIO.setup(LCD_RS, GPIO.OUT)
    GPIO.setup(LCD_D4, GPIO.OUT)
    GPIO.setup(LCD_D5, GPIO.OUT)
    GPIO.setup(LCD_D6, GPIO.OUT)
    GPIO.setup(LCD_D7, GPIO.OUT)

    # Initialize the LCD
    lcd_init()

    # Continuously read temperature and humidity and display on LCD
    while True:
        try:
            # Read data from DHT11 sensor
            humidity, temperature = Adafruit_DHT.read_retry(sensor, dht_pin)
            if humidity is not None and temperature is not None:
                # Prepare messages
                temp_message = f"Temp: {temperature}C"
                hum_message = f"Hum: {humidity}%"

                # Display messages on LCD
                lcd_string(temp_message, LCD_LINE_1)
                lcd_string(hum_message, LCD_LINE_2)
            else:
                # Error message in case of sensor failure
                lcd_string("Sensor Error", LCD_LINE_1)
                lcd_string("Retrying...", LCD_LINE_2)
        except Exception as e:
            lcd_string("Error", LCD_LINE_1)
            lcd_string(str(e)[:16], LCD_LINE_2)

        # Wait for 2 seconds before updating
        time.sleep(2)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    finally:
        lcd_byte(0x01, LCD_CMD)  # Clear display
        lcd_string("Goodbye!", LCD_LINE_1)
        GPIO.cleanup()
