import RPi.GPIO as GPIO
import time
from datetime import datetime

# Pin configuration for LDR Sensor
LED_PIN_LDR = 5  # GPIO pin connected to the LED for LDR
LIGHT_SENSOR_PIN = 33  # GPIO pin connected to the light sensor (digital output)

# Pin configuration for Ultrasonic Sensor
TRIG = 19  # GPIO pin connected to TRIG of the ultrasonic sensor
ECHO = 26  # GPIO pin connected to ECHO of the ultrasonic sensor
LED_PIN_ULTRASONIC = 3  # GPIO pin connected to the LED for Ultrasonic sensor

# Pin configuration for Time-based LED control
LED_PIN_TIME = [2, 3, 4]  # GPIO pin where the LED is connected for time-based control

# Threshold distance for ultrasonic sensor to detect an object (in cm)
DETECTION_THRESHOLD = 30  # Adjust this value based on your requirement
ON_TIME = "12:09"  # Time to turn the LED ON (24-hour format)
OFF_TIME = "12:10"  # Time to turn the LED OFF (24-hour format)

# Setup GPIO mode
GPIO.setmode(GPIO.BCM)
GPIO.setup(LED_PIN_LDR, GPIO.OUT)
GPIO.setup(LIGHT_SENSOR_PIN, GPIO.IN)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
GPIO.setup(LED_PIN_ULTRASONIC, GPIO.OUT, initial=GPIO.LOW)
GPIO.setup(LED_PIN_TIME, GPIO.OUT)
# Function to control the LED based on the LDR (Light Dependent Resistor)
def ldr_control():
    light_level = GPIO.input(LIGHT_SENSOR_PIN)  # Read light sensor (0 for dark, 1 for bright)
    if light_level == 1:  # Dark environment
        GPIO.output(LED_PIN_LDR, GPIO.HIGH)  # Turn LED ON
        print("Dark: LED ON")
    else:  # Bright environment
        GPIO.output(LED_PIN_LDR, GPIO.LOW)  # Turn LED OFF
        print("Bright: LED OFF")

# Function to control the LED based on ultrasonic sensor distance
def ultrasonic_control():
    GPIO.output(TRIG, False)
    time.sleep(2)  # Allow sensor to stabilize

    # Trigger a pulse
    GPIO.output(TRIG, True)
    time.sleep(0.00001)  # 10 microseconds
    GPIO.output(TRIG, False)

    # Measure the time for the pulse to return
    while GPIO.input(ECHO) == 0:
        pulse_start = time.time()

    while GPIO.input(ECHO) == 1:
        pulse_end = time.time()

    # Calculate distance
    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150  # Convert time to distance in cm
    distance = round(distance, 2)  # Round to two decimal places
 if 2 < distance < 400:  # Valid range of sensor
        print(f"Distance: {distance} cm")
        if distance <= DETECTION_THRESHOLD:  # Object detected
            GPIO.output(LED_PIN_ULTRASONIC, GPIO.HIGH)  # Turn on the LED
            print("Object detected! LED ON")
        else:
            GPIO.output(LED_PIN_ULTRASONIC, GPIO.LOW)  # Turn off the LED
    else:
        print("Out of Range")

# Function to control the LED based on the specified ON and OFF times
def time_based_control(on_time, off_time):
    current_time = datetime.now().strftime('%H:%M')  # Current time in hours:minutes format
    print(f"Current time: {current_time}")
    
    if current_time == on_time:
        GPIO.output(LED_PIN_TIME, GPIO.HIGH)  # Turn the LED on
        print(f"LED is ON at {on_time}")
    elif current_time == off_time:
        GPIO.output(LED_PIN_TIME, GPIO.LOW)  # Turn the LED off
        print(f"LED is OFF at {off_time}")

# Main loop
try:
    while True:
        # Call the LDR control function
        ldr_control()

        # Call the ultrasonic sensor control function
        ultrasonic_control()
# Call the time-based LED control function
        time_based_control(ON_TIME, OFF_TIME)

        time.sleep(1)  # Delay to avoid excessive CPU usage
except KeyboardInterrupt:
    print("Program interrupted by user.")
finally:
    GPIO.cleanup()  # Clean up GPIO to reset pin states
    print("GPIO cleanup complete.")