from flask import Flask, request, jsonify
import RPi.GPIO as gpio
import time

app = Flask(__name__)

# Setup GPIO pins
gpio.setwarnings(False)
gpio.setmode(gpio.BOARD)

led_pins = {
    "led2": 12,
    "led3": 3,
    "led4": 5,
}

# Initialize GPIO pins for LEDs
for pin in led_pins.values():
    gpio.setup(pin, gpio.OUT, initial=0)

@app.route("/toggle", methods=["POST"])
def toggle_led():
    """
    Endpoint to toggle LEDs.
    JSON Input: { "led": "led2" }
    """
    data = request.json
    led = data.get("led")

    if led not in led_pins:
        return jsonify({"error": "Invalid LED name"}), 400

    pin = led_pins[led]

    # Toggle the LED
    gpio.output(pin, True)
    time.sleep(0.2)
    gpio.output(pin, False)

    return jsonify({"message": f"{led} toggled successfully"}), 200

@app.route("/")
def home():
    return "LED Control Server is running!", 200

# Cleanup GPIO pins on shutdown
@app.teardown_appcontext
def cleanup(exception=None):
    gpio.cleanup()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
