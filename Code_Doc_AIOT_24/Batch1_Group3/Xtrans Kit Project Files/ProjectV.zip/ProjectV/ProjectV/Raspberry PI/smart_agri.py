import time
import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008
import RPi.GPIO as GPIO

# Moisture Sensor Configuration (MCP3008)
SPI_PORT = 0
SPI_DEVICE = 0
mcp = Adafruit_MCP3008.MCP3008(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))

# Stepper Motor Configuration
GPIO.setmode(GPIO.BCM)  # Use BCM pin numbering
StepPins = [13, 4, 6, 5]  # GPIO pins for the stepper motor

# Set all pins as output
for pin in StepPins:
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, False)

# Define stepper motor sequence for half-step mode
Seq = [[1, 0, 0, 1],
       [1, 0, 0, 0],
       [1, 1, 0, 0],
       [0, 1, 0, 0],
       [0, 1, 1, 0],
       [0, 0, 1, 0],
       [0, 0, 1, 1],
       [0, 0, 0, 1]]

StepCount = len(Seq)
StepDir = 1  # Direction: 1 = Clockwise, -1 = Counterclockwise
WaitTime = 0.01  # Delay between steps (adjust for motor speed)

# Moisture Thresholds
MOISTURE_THRESHOLD_DRY = 500  # Adjust based on your sensor's readings
MOISTURE_THRESHOLD_WET = 500  # Adjust based on your sensor's readings

# Function to rotate stepper motor
def rotate_motor(steps=512, direction=1):
    global StepDir
    StepDir = direction
    StepCounter = 0
    
    for _ in range(steps):
        for pin in range(4):
            xpin = StepPins[pin]
            if Seq[StepCounter][pin] != 0:
                GPIO.output(xpin, True)
            else:
                GPIO.output(xpin, False)

        StepCounter += StepDir

        # Restart the sequence if we reach the end
        if StepCounter >= StepCount:
            StepCounter = 0
        if StepCounter < 0:
            StepCounter = StepCount + StepDir

        time.sleep(WaitTime)

# Main loop for monitoring soil moisture and controlling the stepper motor
try:
    while True:
        # Read soil moisture value
        moisture_value = mcp.read_adc(1)
        print(f"Moisture Value: {moisture_value}")

        if moisture_value < MOISTURE_THRESHOLD_DRY:
            print("Soil is dry. Rotating motor to irrigate...")
            # Rotate the motor for one full rotation (e.g., for irrigation)
            rotate_motor(steps=512, direction=1)
        elif moisture_value > MOISTURE_THRESHOLD_WET:
            print("Soil is wet. Stopping motor...")
            # Stop the motor (do nothing)
            for pin in StepPins:
                GPIO.output(pin, False)
        else:
            print("Soil is in optimal range. Motor remains off.")

        time.sleep(2)  # Check moisture every 2 seconds

except KeyboardInterrupt:
    print("Program stopped by user.")
finally:
    GPIO.cleanup()  # Clean up GPIO settings on exit7
