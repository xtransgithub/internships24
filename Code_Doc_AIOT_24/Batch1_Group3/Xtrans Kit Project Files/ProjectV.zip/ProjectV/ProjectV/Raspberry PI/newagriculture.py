import Adafruit_DHT
import RPi.GPIO as GPIO
import time
import json
from datetime import datetime

# Sensor setup
DHT_SENSOR = Adafruit_DHT.DHT11  # Use DHT22 if applicable
DHT_PIN = 4                      # GPIO pin for DHT sensor
SOIL_MOISTURE_PIN = 17           # GPIO pin for soil moisture sensor

# GPIO setup
GPIO.setmode(GPIO.BCM)
GPIO.setup(SOIL_MOISTURE_PIN, GPIO.IN)

# Log file
LOG_FILE = "agriculture_data.json"

# Function to read humidity and temperature
def read_dht_sensor():
    humidity, temperature = Adafruit_DHT.read_retry(DHT_SENSOR, DHT_PIN)
    if humidity is not None and temperature is not None:
        return {"Temperature": round(temperature, 2), "Humidity": round(humidity, 2)}
    else:
        print("Failed to read from DHT sensor.")
        return None

# Function to read soil moisture
def read_soil_moisture():
    soil_status = GPIO.input(SOIL_MOISTURE_PIN)
    if soil_status == GPIO.LOW:
        return "Dry"
    else:
        return "Wet"

# Function to log data
def log_data(data):
    try:
        with open(LOG_FILE, "a") as file:
            file.write(json.dumps(data) + "\n")
    except Exception as e:
        print(f"Error logging data: {e}")

# Main loop
try:
    while True:
        # Read data from sensors
        dht_data = read_dht_sensor()
        soil_moisture_status = read_soil_moisture()

        if dht_data:
            # Prepare data
            data = {
                "Timestamp": datetime.now().isoformat(),
                "Temperature": dht_data["Temperature"],
                "Humidity": dht_data["Humidity"],
                "Soil Moisture": soil_moisture_status
            }

            # Display data
            print(f"Timestamp: {data['Timestamp']}")
            print(f"Temperature: {data['Temperature']} °C")
            print(f"Humidity: {data['Humidity']} %")
            print(f"Soil Moisture: {data['Soil Moisture']}")

            # Log data
            log_data(data)

        # Delay before the next reading
        time.sleep(10)

except KeyboardInterrupt:
    print("Exiting program...")
    GPIO.cleanup()