from luma.lcd.device import CharLCD
from PIL import ImageFont, ImageDraw, Image

# Set up your display (modify as necessary)
lcd = CharLCD()

# Load your emoji font
font = ImageFont.truetype("path_to_emoji_font.ttf", size=24)

# Create an image to draw on
image = Image.new('RGB', (lcd.width, lcd.height), (255, 255, 255))
draw = ImageDraw.Draw(image)

# Draw the emoji (use the corresponding Unicode)
draw.text((0, 0), "😀", fill="black", font=font)

# Display the image
lcd.display(image)
