import serial
import time
import json
from datetime import datetime

arduino = serial.Serial('/dev/ttyUSBO',9600,timeout=1)
necessary
time.sleep(2)

log_file = "agriculture_data.json"

def log_data(data):
    try:
        with open(log_file,"a") as file:
            file.write(json.dumps(data)+"\n")
    except Exception as e:
            print(f"Error logging data:{e}")
            
def control_irrigation(soil_moisture):
    if soil_moisture<500:
        print("irrigation required. sending signal to arduino...")
        arduino.write(b'PUMP_ON\n')
        time.sleep(5)
        arduino.write(b'PUMP_OFF\n')
        print("irrigation completed")
    else:
        print("soil moisture level sufficient .No irrigation is needed")
        
        try:
            while True:
                if arduino.in_waiting>0:
                    line = arduino.readline().decode('UTF-8').STRIP()
                    print(f"Received:{line}")
                    
        try:
            data = {}
            for item in line.split(",")
            data[key.strip()] = float(value.strip())
            
            data["Timestamp"] = datetime.now().isoformat()
            
            log_data(data)
            
            print(f"Temperature:{data['Temperature']}")
            print(f"Humidity:{data['Humidity']}%")
            print(f"Soil Moisture:{data['Soil Moisture']}")
            
            control_irrigation(data['Soil Moisture'])
        except Exception as e:
            print(f"Error parsing data:{e}")
            
        time.sleep(2)
    except keyboardinterrupt:
        print("Exiting...")
        arduino.close()
            




            
