import RPi.GPIO as GPIO
import time

# Pin configurations
light_sensor_pin = 33  # Light sensor pin
buzzer_pin = 38        # Buzzer pin

def setup():
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(light_sensor_pin, GPIO.IN)
    GPIO.setup(buzzer_pin, GPIO.OUT)

def read_light_and_control_buzzer():
    while True:
        light_state = GPIO.input(light_sensor_pin)
        
        if light_state == 0:  # No light detected
            print("LIGHT NOT DETECTED - BUZZER ON")
            GPIO.output(buzzer_pin, GPIO.HIGH)  # Sound buzzer
        else:  # Light detected
            print("LIGHT DETECTED - BUZZER OFF")
            GPIO.output(buzzer_pin, GPIO.LOW)   # Turn off buzzer
        
        time.sleep(0.3)

def destroy():
    GPIO.cleanup()

if __name__ == '__main__':
    try:
        setup()
        read_light_and_control_buzzer()
    except KeyboardInterrupt:
        destroy()
