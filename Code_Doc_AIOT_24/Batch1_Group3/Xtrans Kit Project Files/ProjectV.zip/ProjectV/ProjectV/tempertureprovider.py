import Adafruit_DHT
import requests
import time

# Sensor configuration
DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 4

# Server URL
SERVER_URL = 'http://192.168.14.176:5000/log'


def read_sensor():
    """
    Reads data from the DHT11 sensor.
    Returns the temperature if the read is successful, otherwise None.
    """
    humidity, temperature = Adafruit_DHT.read(DHT_SENSOR, DHT_PIN)
    if humidity is not None and temperature is not None:
        return temperature
    return None

def send_temperature(temperature):
    """
    Sends the temperature data to the server.
    Handles request errors gracefully.
    """
    try:
        response = requests.post(SERVER_URL, json={"temper": temperature})

    except requests.exceptions.RequestException as e:
        print(f"Failed to send request: {e}")

def main():
    """
    Main function to continuously read the sensor and send data.
    """
    while True:
        temperature = read_sensor()
        if temperature is not None:
            print(f"Temperature: {temperature}°C")
            send_temperature(temperature)
        else:
            print("Failed to read from sensor.")
        # Delay between readings
        time.sleep(2)

if __name__ == "__main__":
    main()
