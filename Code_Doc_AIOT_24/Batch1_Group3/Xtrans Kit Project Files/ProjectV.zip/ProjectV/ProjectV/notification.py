import requests
import RPi.GPIO as GPIO
import time
import requests
import json
GPIO.setmode(GPIO.BCM)  # Set GPIO pin numbering

TRIG = 19  # Associate pin 19 with TRIG
ECHO = 26  # Associate pin 26 with ECHO

print("Distance measurement in progress")

GPIO.setup(TRIG, GPIO.OUT)  # Set TRIG pin as output
GPIO.setup(ECHO, GPIO.IN)   # Set ECHO pin as input

SERVER_URL = 'http://192.168.14.176:5000/send_notification'  # http://ip-address:port/send_notification

while True:
    GPIO.output(TRIG, False)  # Set TRIG as LOW
    print("Waiting For Sensor To Settle")
    time.sleep(2)  # Delay for sensor to settle

    GPIO.output(TRIG, True)  # Send a pulse
    time.sleep(0.00001)  # Pulse duration
    GPIO.output(TRIG, False)  # End pulse

    while GPIO.input(ECHO) == 0:  # Wait for ECHO to go HIGH
        pulse_start = time.time()

    while GPIO.input(ECHO) == 1:  # Wait for ECHO to go LOW
        pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start  # Calculate pulse duration
    distance = pulse_duration * 17150  # Calculate distance in cm
    distance = round(distance, 2)  # Round to 2 decimal places

    # Check distance and send data to Flask server
    if distance < 35:
        data = {'message': 'Somebody is at the door!!'}
        response = requests.post(SERVER_URL, json=data)
        if response.status_code == 200:
            print("Notification sent successfully!")
        else:
            print("Failed to send notification.")
        print("Alert data sent to Flask")
    else:
        
        print("No alert data sent to Flask")

    time.sleep(1)  # Delay before the next reading





