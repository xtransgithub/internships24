import RPi.GPIO as GPIO
import time

# Stepper motor pins
STEP_PIN = 17
DIR_PIN = 18
EN_PIN = 22

# Setup GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(STEP_PIN, GPIO.OUT)
GPIO.setup(DIR_PIN, GPIO.OUT)
GPIO.setup(EN_PIN, GPIO.OUT)

# Function to move stepper motor
def move_stepper(steps, direction):
    GPIO.output(DIR_PIN, direction)  # Set the direction (True = Clockwise, False = Anticlockwise)
    GPIO.output(EN_PIN, GPIO.HIGH)   # Enable the motor
    for _ in range(steps):
        GPIO.output(STEP_PIN, GPIO.HIGH)
        time.sleep(0.01)
        GPIO.output(STEP_PIN, GPIO.LOW)
        time.sleep(0.01)
    GPIO.output(EN_PIN, GPIO.LOW)    # Disable the motor

# Rotate clockwise (unlock)
def unlock_door():
    print("Unlocking door...")
    move_stepper(512, True)

# Rotate anticlockwise (lock)
def lock_door():
    print("Locking door...")
    move_stepper(512, False)

if __name__ == "__main__":
    unlock_door()
    time.sleep(5)  # Keep the door open for 5 seconds
    lock_door()
    GPIO.cleanup()
