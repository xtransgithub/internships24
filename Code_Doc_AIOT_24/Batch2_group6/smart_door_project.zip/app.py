import qrcode
import RPi.GPIO as GPIO
import time
import sys

# Set up the GPIO pins for controlling the stepper motor
StepPins = [13, 4, 6, 5]  # Stepper motor pins
GPIO.setmode(GPIO.BCM)

# Set all pins as output
for pin in StepPins:
    GPIO.setup(pin, GPIO.OUT)
    GPIO.output(pin, False)

# Define advanced sequence as per datasheet
Seq = [
    [1, 0, 0, 1],
    [1, 0, 0, 0],
    [1, 1, 0, 0],
    [0, 1, 0, 0],
    [0, 1, 1, 0],
    [0, 0, 1, 0],
    [0, 0, 1, 1],
    [0, 0, 0, 1]
]

StepCount = len(Seq)
StepDir = 1  # Set to 1 for clockwise, -1 for counterclockwise
WaitTime = 10 / float(100)  # Adjust speed of rotation

# Function to rotate the stepper motor
def rotate_stepper(steps, direction=1):
    global StepDir, StepCounter
    StepDir = direction
    StepCounter = 0
    
    # Rotate the motor for the number of steps
    for _ in range(steps):
        for pin in range(4):
            xpin = StepPins[pin]
            if Seq[StepCounter][pin] != 0:
                GPIO.output(xpin, True)
            else:
                GPIO.output(xpin, False)
        
        StepCounter += StepDir
        
        # If we reach the end of the sequence, restart
        if StepCounter >= StepCount:
            StepCounter = 1
        if StepCounter < 1:
            StepCounter = StepCount + StepDir
        
        # Wait before moving on
        time.sleep(WaitTime)

# Function to generate a QR code
def generate_qr_code(url):
    print("Generating QR code...")
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)

    img = qr.make_image(fill='black', back_color='white')
    img.show()

# Main execution
if __name__ == "__main__":
    # URL for QR code
    url = "https://docs.google.com/forms/d/e/1FAIpQLSdXKU8hy8H2LyNDT_OcsDjGS6aptJ-_bnwA6H5MSoAM-ucBbw/viewform?fbzx=531413744948061679"  # Replace with your URL

    # Step 1: Rotate the stepper motor clockwise
    print("Rotating the stepper motor clockwise...")
    rotate_stepper(100, direction=1)  # Rotate 20 steps clockwise

    # Step 2: Generate QR Code
    generate_qr_code(url)

    # Wait for user to "submit" the form (simulate this with a delay)
    print("Please fill and submit the Google form...")
    time.sleep(25)  # Simulate waiting for form submission (adjust time as needed)

    # Step 3: Rotate the stepper motor counterclockwise after form submission
    print("Rotating the stepper motor counterclockwise...")
    rotate_stepper(100, direction=-1)  # Rotate 20 steps counterclockwise

    # Clean up GPIO settings
    GPIO.cleanup()
