import requests
import RPi.GPIO as GPIO
import time
import sys

# GPIO pin setup
TRIG = 19  # Trigger pin
ECHO = 26  # Echo pin
StepPins = [13, 4, 6, 5]  # Motor control pins

GPIO.setmode(GPIO.BCM)  # Use BCM GPIO numbering
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

# Define Flask server URL
SERVER_URL = "http://your-flask-server-url"  # Replace with your server's URL

def motor():
    """Control stepper motor based on predefined sequence."""
    for pin in StepPins:
        GPIO.setup(pin, GPIO.OUT)
        GPIO.output(pin, False)

    Seq = [[1, 0, 0, 1],
           [1, 0, 0, 0],
           [1, 1, 0, 0],
           [0, 1, 0, 0],
           [0, 1, 1, 0],
           [0, 0, 1, 0],
           [0, 0, 1, 1],
           [0, 0, 0, 1]]

    StepCount = len(Seq)
    StepDir = 2  # Clockwise

    WaitTime = 10 / float(100)  # Delay between steps
    StepCounter = 0

    # Run motor for a limited time
    for _ in range(100):  # Adjust iterations as needed
        for pin in range(4):
            xpin = StepPins[pin]
            GPIO.output(xpin, Seq[StepCounter][pin] == 1)
        StepCounter += StepDir

        if StepCounter >= StepCount:
            StepCounter = 0
        if StepCounter < 0:
            StepCounter = StepCount + StepDir

        time.sleep(WaitTime)

def measure_distance():
    """Measure distance using ultrasonic sensor."""
    GPIO.output(TRIG, False)
    time.sleep(0.2)

    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    pulse_start = time.time()
    timeout = time.time() + 1  # 1-second timeout for echo

    while GPIO.input(ECHO) == 0:
        pulse_start = time.time()
        if time.time() > timeout:
            return None

    while GPIO.input(ECHO) == 1:
        pulse_end = time.time()
        if time.time() > timeout:
            return None

    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150
    return round(distance, 2)

try:
    while True:
        distance = measure_distance()
        if distance is not None:
            print(f"Distance: {distance} cm")
            if distance < 35:
                print("Alert: Object detected within 35 cm!")

                motor()
            else:
                print("No alert. Distance is safe.")

        else:
            print("Sensor timeout. Unable to measure distance.")

        time.sleep(1)

except KeyboardInterrupt:
    print("\nExiting program.")

finally:
    GPIO.cleanup()
