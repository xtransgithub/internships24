import RPi.GPIO as GPIO
import time
import csv

# Stepper motor GPIO pins
motor_pins = [13, 4, 6, 5]

def setup_motor():
    """Setup GPIO for stepper motor control."""
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)
    for pin in motor_pins:
        GPIO.setup(pin, GPIO.OUT)

def rotate_motor_90_degrees():
    """Rotate the stepper motor by 90 degrees."""
    step_sequence = [
        [1, 0, 0, 1],
        [1, 0, 0, 0],
        [1, 1, 0, 0],
        [0, 1, 0, 0],
        [0, 1, 1, 0],
        [0, 0, 1, 0],
        [0, 0, 1, 1],
        [0, 0, 0, 1]
    ]
    for _ in range(50):  # Adjust for your motor
        for step in step_sequence:
            for pin in range(4):
                GPIO.output(motor_pins[pin], step[pin])
            time.sleep(0.01)

def reset_motor():
    """Reset the stepper motor to its initial position."""
    step_sequence = [
        [1, 0, 0, 1],
        [1, 0, 0, 0],
        [1, 1, 0, 0],
        [0, 1, 0, 0],
        [0, 1, 1, 0],
        [0, 0, 1, 0],
        [0, 0, 1, 1],
        [0, 0, 0, 1]
    ]
    for _ in range(50):  # Adjust for your motor
        for step in reversed(step_sequence):
            for pin in range(4):
                GPIO.output(motor_pins[pin], step[pin])
            time.sleep(0.01)

def log_event(usn, name):
    """Log the event to a CSV file."""
    with open('motor_log.csv', mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), usn, name, "90-degree rotation completed"])
    print("Event logged.")

def cleanup_motor():
    """Clean up GPIO settings."""
    GPIO.cleanup()
