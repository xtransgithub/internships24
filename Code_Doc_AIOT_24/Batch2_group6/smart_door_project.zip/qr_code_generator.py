import qrcode

# URL to the Google Form (replace with your actual form URL)
google_form_url = "https://forms.gle/yourGoogleFormID"  # Update with your Google Form link

# Generate QR code
qr = qrcode.QRCode(
    version=1,
    error_correction=qrcode.constants.ERROR_CORRECT_L,
    box_size=10,
    border=4,
)

qr.add_data(google_form_url)
qr.make(fit=True)

# Create an image of the QR code
img = qr.make_image(fill='black', back_color='white')

# Save the QR code as an image file
img.save("door_qr_code.png")

print("QR Code saved successfully as door_qr_code.png")
