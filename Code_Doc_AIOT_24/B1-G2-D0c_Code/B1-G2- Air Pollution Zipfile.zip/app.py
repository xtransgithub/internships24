from flask import Flask, jsonify, render_template, session, redirect, url_for, request
import requests


app = Flask(__name__)
app.secret_key = "your_secret_key"


# Route to serve the dashboard page
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username == "admin" and password == "password":
            session["user"] = username
            return redirect(url_for("dashboard"))
        return "Invalid credentials"
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))
    return render_template("dashboard.html")

# Route to fetch sensor data and send it to the frontend
@app.route('/get_data', methods=["GET"])
def get_data():
    # Here, you would fetch the data from your Raspberry Pi app (sensor data)
    # Example: Make a request to the Raspberry Pi backend (assuming it's running at 192.168.1.x)
    try:
        response = requests.get('http://192.168.14.35:5000/get_data')
        data = response.json()
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)})
    

@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)  # You can change the port if needed
