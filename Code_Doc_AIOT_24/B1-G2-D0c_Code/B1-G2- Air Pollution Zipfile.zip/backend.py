from flask import Flask, jsonify
import Adafruit_DHT
import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008
from twilio.rest import Client
import RPi.GPIO as GPIO
import time
import requests

# Flask setup
app = Flask(__name__)

# Twilio Configuration
TWILIO_ACCOUNT_SID = "ACf5fcb418d8b83c909a2102d70899bb5b"  # Replace with your Twilio Account SID
TWILIO_AUTH_TOKEN = "238fe1227f2d9b5ddb3cc6492bf916cb"    # Replace with your Twilio Auth Token
TWILIO_PHONE_NUMBER = "+16812244287"                      # Replace with your Twilio phone number
ALERT_PHONE_NUMBER = "+918309252517"                      # Replace with the recipient's phone number

# ThingSpeak Configuration
THINGSPEAK_WRITE_API_KEY = "JCFQ4KUK06A2SKBS"  # Replace with your ThingSpeak channel Write API key
THINGSPEAK_URL = "https://api.thingspeak.com/update"

# Sensor Configurations
SPI_PORT = 0
SPI_DEVICE = 0
mcp = Adafruit_MCP3008.MCP3008(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))
DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 4

# GPIO Configuration
BUZZER_PIN = 38
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(BUZZER_PIN, GPIO.OUT)
GPIO.output(BUZZER_PIN, GPIO.LOW)

# AQI Breakpoints (CO-specific for example purposes)
CO_BREAKPOINTS = [
    {"C_low": 0.0, "C_high": 4.4, "I_low": 0, "I_high": 50},
    {"C_low": 4.5, "C_high": 9.4, "I_low": 51, "I_high": 100},
    {"C_low": 9.5, "C_high": 12.4, "I_low": 101, "I_high": 150},
    {"C_low": 12.5, "C_high": 15.4, "I_low": 151, "I_high": 200},
]

# Function to send SMS alerts using Twilio
def send_sms_alert(message):
    try:
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        sms = client.messages.create(
            body=message,
            from_=TWILIO_PHONE_NUMBER,
            to=ALERT_PHONE_NUMBER
        )
        print(f"SMS sent: {sms.sid}")
    except Exception as e:
        print(f"Error sending SMS: {e}")

# Function to calculate AQI based on CO concentration
def calculate_aqi(concentration, breakpoints):
    for bp in breakpoints:
        if bp["C_low"] <= concentration <= bp["C_high"]:
            aqi = ((bp["I_high"] - bp["I_low"]) / (bp["C_high"] - bp["C_low"])) * \
                  (concentration - bp["C_low"]) + bp["I_low"]
            return round(aqi)
    return None

# Function to trigger the buzzer
def trigger_buzzer(duration=2):
    GPIO.output(BUZZER_PIN, GPIO.HIGH)
    time.sleep(duration)
    GPIO.output(BUZZER_PIN, GPIO.LOW)

# Function to send data to ThingSpeak
def send_to_thingspeak(data):
    payload = {
        "api_key": THINGSPEAK_WRITE_API_KEY,
        "field1": data['gas_ppm'],
        "field2": data['temperature'],
        "field3": data['humidity'],
        "field4": data['aqi'],
    }
    try:
        response = requests.post(THINGSPEAK_URL, data=payload)
        if response.status_code == 200:
            print(f"Data sent to ThingSpeak successfully: {response.text}")
        else:
            print(f"Failed to send data to ThingSpeak: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"Error sending data to ThingSpeak: {e}")

# Function to get sensor data and handle alerts
def get_sensor_data():
    gas_value = mcp.read_adc(0)  # Raw gas sensor value
    gas_ppm = gas_value / 100.0  # Example conversion to ppm
    aqi = calculate_aqi(gas_ppm, CO_BREAKPOINTS)
    humidity, temperature = Adafruit_DHT.read_retry(DHT_SENSOR, DHT_PIN)

    alerts = []
    recommendations = []

    # Alert and recommendation logic
    if gas_ppm > 100:
        recommendations.append("Gas levels are high. Ventilate the room or use an air purifier.")
        alerts.append("High gas levels detected.")
        send_sms_alert("High gas levels detected. Please take precautions!")
        trigger_buzzer()

    if aqi and aqi > 150:
        recommendations.append(f"Unhealthy air quality detected. Current AQI: {aqi}.")
        alerts.append(f"AQI alert: {aqi}.")
        if aqi > 200:
            send_sms_alert(f"Critical AQI detected: {aqi}. Avoid outdoor activities.")
        trigger_buzzer()

    if temperature > 35:
        recommendations.append("High temperature detected. Use air conditioning.")
        alerts.append(f"High temperature: {temperature}°C.")

    if humidity < 20:
        recommendations.append("Low humidity detected. Use a humidifier.")
        alerts.append(f"Low humidity: {humidity}%.")

    data = {
        "gas_raw": gas_value,
        "gas_ppm": gas_ppm,
        "temperature": temperature or 0,
        "humidity": humidity or 0,
        "aqi": aqi or 0,
        "alerts": alerts,
        "recommendations": recommendations,
    }

    # Send data to ThingSpeak (independent of SMS alert logic)
    send_to_thingspeak(data)
    return data

# Flask route to get data
@app.route("/get_data", methods=["GET"])
def get_data():
    data = get_sensor_data()
    return jsonify(data)

# Flask app entry point
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)