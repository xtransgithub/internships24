import time
import Adafruit_DHT
import RPi.GPIO as GPIO
import requests
from flask import Flask, render_template, request

# Set the type of sensor and the pin for the sensor
sensor = Adafruit_DHT.DHT11
pin = 4

# GPIO for LED
led2 = 12  # Pin connected to the LED

# GPIO for LCD
LCD_RS = 15
LCD_E = 12
LCD_D4 = 23
LCD_D5 = 21
LCD_D6 = 19
LCD_D7 = 24

# LCD Settings
LCD_WIDTH = 16  # Maximum characters per line
LCD_CHR = True
LCD_CMD = False
LCD_LINE_1 = 0x80  # LCD RAM address for the 1st line
LCD_LINE_2 = 0xC0  # LCD RAM address for the 2nd line
E_PULSE = 0.0005
E_DELAY = 0.0005

# API setup
API_KEY = "8be8c75ec928f9c61987f56bce3028aa"  # Replace with your actual API key
BASE_URL = "http://api.openweathermap.org/data/2.5/forecast"

# Flask Setup
app = Flask(__name__)

def init_gpio():
    """Initialize GPIO for LED and LCD."""
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD)

    # Setup GPIO for LED
    GPIO.setup(led2, GPIO.OUT, initial=0)

    # Setup GPIO for LCD
    GPIO.setup(LCD_E, GPIO.OUT)
    GPIO.setup(LCD_RS, GPIO.OUT)
    GPIO.setup(LCD_D4, GPIO.OUT)
    GPIO.setup(LCD_D5, GPIO.OUT)
    GPIO.setup(LCD_D6, GPIO.OUT)
    GPIO.setup(LCD_D7, GPIO.OUT)

    # Initialize LCD
    lcd_init()

def lcd_init():
    """Initialize LCD."""
    lcd_byte(0x33, LCD_CMD)  # 110011 Initialize
    lcd_byte(0x32, LCD_CMD)  # 110010 Initialize
    lcd_byte(0x06, LCD_CMD)  # 000110 Cursor move direction
    lcd_byte(0x0C, LCD_CMD)  # 001100 Display On, Cursor Off, Blink Off
    lcd_byte(0x28, LCD_CMD)  # 101000 Data length, number of lines, font size
    lcd_byte(0x01, LCD_CMD)  # 000001 Clear display
    time.sleep(E_DELAY)

def lcd_byte(bits, mode):
    """Send byte to data pins."""
    GPIO.output(LCD_RS, mode)  # RS

    # High bits
    GPIO.output(LCD_D4, bits & 0x10 == 0x10)
    GPIO.output(LCD_D5, bits & 0x20 == 0x20)
    GPIO.output(LCD_D6, bits & 0x40 == 0x40)
    GPIO.output(LCD_D7, bits & 0x80 == 0x80)

    lcd_toggle_enable()

    # Low bits
    GPIO.output(LCD_D4, bits & 0x01 == 0x01)
    GPIO.output(LCD_D5, bits & 0x02 == 0x02)
    GPIO.output(LCD_D6, bits & 0x04 == 0x04)
    GPIO.output(LCD_D7, bits & 0x08 == 0x08)

    lcd_toggle_enable()

def lcd_toggle_enable():
    """Toggle enable pin."""
    time.sleep(E_DELAY)
    GPIO.output(LCD_E, True)
    time.sleep(E_PULSE)
    GPIO.output(LCD_E, False)
    time.sleep(E_DELAY)

def lcd_string(message, line):
    """Send string to display."""
    message = message.ljust(LCD_WIDTH, " ")
    lcd_byte(line, LCD_CMD)

    for i in range(LCD_WIDTH):
        lcd_byte(ord(message[i]), LCD_CHR)

def get_weather_data(city_name):
    """Fetch city weather from OpenWeatherMap API."""
    url = f"{BASE_URL}?q={city_name}&appid={API_KEY}&units=metric"
    response = requests.get(url)

    weather_data = None
    if response.status_code == 200:
        data = response.json()
        city = data["city"]["name"]
        temp = data["list"][0]["main"]["temp"]
        weather_desc = data["list"][0]["weather"][0]["description"]
        weather_data = {
            "city": city,
            "temp": temp,
            "weather_desc": weather_desc
        }
    return weather_data

@app.route("/", methods=["GET", "POST"])
def index():
    weather = None
    if request.method == "POST":
        city_name = request.form["city"]
        weather = get_weather_data(city_name)
        if weather:
            lcd_string(f"City: {weather['city']}", LCD_LINE_1)
            lcd_string(f"Temp: {weather['temp']}C", LCD_LINE_2)
        else:
            lcd_string("API Error", LCD_LINE_1)

    return render_template("index.html", weather=weather)

def read_local_temp():
    """Read local temperature and control LED."""
    humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)

    if humidity is not None and temperature is not None:
        lcd_string(f"Temp: {temperature}C", LCD_LINE_2)

        # Control LED
        if temperature > 25:
            GPIO.output(led2, True)
        else:
            GPIO.output(led2, False)
    else:
        print("Failed to read sensor data.")

if __name__ == "__main__":
    init_gpio()
    app.run(host='0.0.0.0', port=5000)
