from flask import Flask, render_template, jsonify
import RPi.GPIO as GPIO
import spidev
import time
import Adafruit_DHT

app = Flask(__name__)

# GPIO and other configuration
GPIO.setmode(GPIO.BCM)  # Use BCM numbering
GPIO.setwarnings(False)

# Pin configurations
LED_PIN = 5               # Pin for the LED to indicate light levels
LIGHT_SENSOR_PIN = 0      # Pin for analog light sensor (via ADC)
SPI_CHANNEL = 0           # SPI Channel for ADC

# ADC Configuration (for light sensor)
spi = spidev.SpiDev()
spi.open(0, SPI_CHANNEL)
spi.max_speed_hz = 1350000

# Threshold for light sensor
LIGHT_THRESHOLD = 700     # Threshold for detecting light/dark

# Setup GPIO pins
GPIO.setup(LED_PIN, GPIO.OUT, initial=GPIO.LOW)  # Set LED pin as OUTPUT (initial state OFF)

def read_adc(channel):
    """Read ADC value from the given channel."""
    if channel < 0 or channel > 7:
        return -1
    adc = spi.xfer2([1, (8 + channel) << 4, 0])
    return ((adc[1] & 3) << 8) + adc[2]

def get_light_status():
    """Get light sensor data and control the LED."""
    light_value = read_adc(LIGHT_SENSOR_PIN)
    if light_value < LIGHT_THRESHOLD:  # Dark environment detected
        GPIO.output(LED_PIN, GPIO.HIGH)  # Turn on LED
        return {"light_value": light_value, "light_status": "Dark", "led_status": "ON"}
    else:  # Light environment detected
        GPIO.output(LED_PIN, GPIO.LOW)  # Turn off LED
        return {"light_value": light_value, "light_status": "Bright", "led_status": "OFF"}

# ADC Setup for additional sensors
SPI_CHANNEL = 0
spi = spidev.SpiDev()
spi.open(0, SPI_CHANNEL)
spi.max_speed_hz = 1350000

def read_adc(channel):
    if channel < 0 or channel > 7:
        return -1
    adc = spi.xfer2([1, (8 + channel) << 4, 0])
    return ((adc[1] & 3) << 8) + adc[2]

# Temperature and Humidity Sensor Setup
DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 4

def get_temperature_data():
    humidity, temperature = Adafruit_DHT.read(DHT_SENSOR, DHT_PIN)
    if humidity is not None and temperature is not None:
        return {"temperature": temperature, "humidity": humidity}
    return {"temperature": "N/A", "humidity": "N/A"}

# Motion Sensor Setup
TRIG = 19
ECHO = 26
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

def get_motion_data():
    GPIO.output(TRIG, False)
    time.sleep(0.002)  # Wait for sensor to settle

    GPIO.output(TRIG, True)
    time.sleep(0.00001)  # Send pulse
    GPIO.output(TRIG, False)

    pulse_start = time.time()
    while GPIO.input(ECHO) == 0:
        pulse_start = time.time()

    pulse_end = time.time()
    while GPIO.input(ECHO) == 1:
        pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150  # Convert to cm

    motion_detected = distance < 30  # Detect motion within 30 cm
    return {"motion_detected": motion_detected, "distance": distance}
    
# Flask Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/light')
def light_monitoring():
    light_data = get_light_status()
    return render_template('light.html', light_value=light_data["light_value"], light_status=light_data["light_status"])

@app.route('/light_data')
def light_data():
    return jsonify(get_light_status())

@app.route('/temperature')
def temperature():
    data = get_temperature_data()
    return render_template('temperature.html', temperature=data['temperature'], humidity=data['humidity'])

@app.route('/motion')
def motion_detection():
    data = get_motion_data()
    return render_template('motion.html', motion_detected=data['motion_detected'], distance=data['distance'])

@app.route('/gas')
def gas_sensor():
    gas_value = read_adc(1)  # Gas sensor data (ADC channel 1)
    return render_template('gas.html', gas_value=gas_value)

@app.route('/temperature_data')
def temperature_data():
    return jsonify(get_temperature_data())

@app.route('/motion_data')
def motion_data():
    return jsonify(get_motion_data())

if __name__ == "__main__":
    try:
        app.run(host='0.0.0.0', port=5000, debug=True)
    except KeyboardInterrupt:
        GPIO.cleanup()  # Cleanup GPIO pins on exit
        spi.close()
