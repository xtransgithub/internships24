import RPi.GPIO as GPIO
import time
import requests
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from threading import Thread, Lock
from pad4pi import rpi_gpio
import os

# GPIO Setup
GPIO.setmode(GPIO.BCM)
TRIG = 19
ECHO = 26
RELAY_PIN = 36
GPIO.setwarnings(False)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
GPIO.setup(RELAY_PIN, GPIO.OUT)

# Keypad Setup
KEYPAD = [
    ["y", "e", "s", "A"],  # For booking
    ["n", "o", "X", "B"],  # For declining
    ["f", "r", "E", "C"],  # 'f' for freeing slot
    ["*", "0", "#", "D"]
]
ROW_PINS = [22, 18, 2, 3]
COL_PINS = [8, 10, 9, 11]
factory = rpi_gpio.KeypadFactory()
keypad = factory.create_keypad(keypad=KEYPAD, row_pins=ROW_PINS, col_pins=COL_PINS)

# Flask App
app = Flask(__name__)
CORS(app)

# Lock for thread-safe operations
slot_lock = Lock()

# Parking Slot Status
parking_slots = {
    "slot1": "available",
    "slot2": "available",
    "slot3": "available",
    "slot4": "unavailable"
}

# Track occupied slots with vehicle info (optional)
occupied_slots = {}

# Create a directory for static files
static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
os.makedirs(static_dir, exist_ok=True)

# Save HTML content to static directory
html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Parking System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; }
        header { background-color: #2c3e50; color: white; padding: 10px 20px; }
        .hero-section { background-color: #3498db; color: white; padding: 50px; text-align: center; }
        .slots-section { padding: 20px; text-align: center; }
        .slots-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin: 20px auto; max-width: 400px; }
        .slot { padding: 20px; border-radius: 8px; text-align: center; font-weight: bold; cursor: pointer; }
        .slot.available { background-color: #2ecc71; color: white; }
        .slot.unavailable { background-color: #e74c3c; color: white; }
        .button-container { margin-top: 10px; }
        .free-button { 
            background-color: #3498db;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            display: none;
        }
        .slot.unavailable .free-button { display: inline-block; }
    </style>
</head>
<body>
    <header>
        <h1>Smart Parking System</h1>
    </header>
    <section class="hero-section">
        <h2>Welcome to Smart Parking</h2>
        <p>Find and manage your parking slot with ease.</p>
    </section>
    <section class="slots-section">
        <h2>Parking Slot Status</h2>
        <div class="slots-grid" id="slotsGrid">
            <div id="slot1" class="slot available">
                Slot 1
                <div class="button-container">
                    <button class="free-button" onclick="freeSlot('slot1')">Free Slot</button>
                </div>
            </div>
            <div id="slot2" class="slot available">
                Slot 2
                <div class="button-container">
                    <button class="free-button" onclick="freeSlot('slot2')">Free Slot</button>
                </div>
            </div>
            <div id="slot3" class="slot available">
                Slot 3
                <div class="button-container">
                    <button class="free-button" onclick="freeSlot('slot3')">Free Slot</button>
                </div>
            </div>
            <div id="slot4" class="slot unavailable">
                Slot 4
                <div class="button-container">
                    <button class="free-button" onclick="freeSlot('slot4')">Free Slot</button>
                </div>
            </div>
        </div>
    </section>
    <script>
        async function fetchSlots() {
            try {
                const response = await fetch("/get_slots");
                const slots = await response.json();
                Object.keys(slots).forEach(slotId => {
                    const slotElement = document.getElementById(slotId);
                    if (slotElement) {
                        if (slots[slotId] === "available") {
                            slotElement.classList.remove("unavailable");
                            slotElement.classList.add("available");
                            slotElement.firstChild.textContent = `${slotId.charAt(0).toUpperCase() + slotId.slice(1)} - Available`;
                        } else {
                            slotElement.classList.remove("available");
                            slotElement.classList.add("unavailable");
                            slotElement.firstChild.textContent = `${slotId.charAt(0).toUpperCase() + slotId.slice(1)} - Reserved`;
                        }
                    }
                });
            } catch (error) {
                console.error("Error fetching slots:", error);
            }
        }

        async function freeSlot(slotId) {
            try {
                const response = await fetch("/free_slot", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({ slot_id: slotId })
                });
                
                if (response.ok) {
                    fetchSlots();  // Refresh the display
                } else {
                    const error = await response.json();
                    alert(error.error || "Failed to free slot");
                }
            } catch (error) {
                console.error("Error freeing slot:", error);
                alert("Failed to free slot");
            }
        }

        setInterval(fetchSlots, 5000); // Fetch slots every 5 seconds
        fetchSlots(); // Initial fetch
    </script>
</body>
</html>
"""

with open(os.path.join(static_dir, 'index.html'), 'w') as f:
    f.write(html_content)

@app.route('/')
def serve_index():
    """Serve the main HTML page."""
    return send_from_directory(static_dir, 'index.html')

@app.route("/book_slot", methods=["POST"])
def book_slot():
    """Book a parking slot."""
    data = request.json
    slot_id = data.get("slot_id")
    with slot_lock:
        if slot_id in parking_slots and parking_slots[slot_id] == "available":
            parking_slots[slot_id] = "unavailable"
            occupied_slots[slot_id] = time.time()  # Record booking time
            print(f"Updated slots: {parking_slots}")
            return jsonify({"message": "Slot booked successfully!"}), 200
        else:
            return jsonify({"error": "Slot unavailable or invalid."}), 400

@app.route("/free_slot", methods=["POST"])
def free_slot():
    """Free up a parking slot."""
    data = request.json
    slot_id = data.get("slot_id")
    with slot_lock:
        if slot_id in parking_slots and parking_slots[slot_id] == "unavailable":
            parking_slots[slot_id] = "available"
            if slot_id in occupied_slots:
                del occupied_slots[slot_id]
            print(f"Freed slot {slot_id}. Updated slots: {parking_slots}")
            return jsonify({"message": "Slot freed successfully!"}), 200
        else:
            return jsonify({"error": "Slot already available or invalid."}), 400

@app.route("/get_slots", methods=["GET"])
def get_slots():
    """Get all parking slot statuses."""
    return jsonify(parking_slots), 200

def book_slot_from_sensor(slot_id):
    """Send a booking request to the Flask server."""
    try:
        response = requests.post("http://localhost:5000/book_slot", json={"slot_id": slot_id})
        if response.status_code == 200:
            print("Slot booked successfully!")
        else:
            print(f"Failed to book slot: {response.json().get('error', 'Unknown error')}")
    except Exception as e:
        print(f"Error: {e}")

def free_slot_from_sensor(slot_id):
    """Send a request to free up a slot."""
    try:
        response = requests.post("http://localhost:5000/free_slot", json={"slot_id": slot_id})
        if response.status_code == 200:
            print("Slot freed successfully!")
        else:
            print(f"Failed to free slot: {response.json().get('error', 'Unknown error')}")
    except Exception as e:
        print(f"Error: {e}")

def sensor_loop():
    """Continuously check sensor data and control the relay."""
    user_response = []  # To store the response (yes/no/free) from the keypad
    
    def handle_keypress(key):
        """Handle keypresses for the yes/no/free prompt."""
        print(f"Key pressed: {key}")
        user_response.append(key)

    keypad.registerKeyPressHandler(handle_keypress)
    
    try:
        print("Sensor loop started...")
        print("Commands: 'y' to book, 'n' to cancel, 'f' to free slot")
        while True:
            # Trigger ultrasonic sensor
            GPIO.output(TRIG, False)
            time.sleep(2)
            GPIO.output(TRIG, True)
            time.sleep(0.00001)
            GPIO.output(TRIG, False)

            # Measure distance
            while GPIO.input(ECHO) == 0:
                pulse_start = time.time()
            while GPIO.input(ECHO) == 1:
                pulse_end = time.time()

            pulse_duration = pulse_end - pulse_start
            distance = pulse_duration * 17150
            distance = round(distance, 2)

            # Check distance and control relay
            if 0 <= distance <= 100:
                print(f"Distance: {distance} cm - Object Detected")
                GPIO.output(RELAY_PIN, GPIO.LOW)  # Relay OFF
                print("Options: 'y' to book slot, 'n' to cancel, 'f' to free slot")

                # Wait for a valid keypress
                user_response.clear()
                while not user_response or user_response[-1] not in ["y", "n", "f"]:
                    time.sleep(0.1)  # Poll for input

                if user_response[-1] == "y":
                    print("Yes detected! Booking slot...")
                    # Find first available slot
                    available_slot = next((slot_id for slot_id, status in parking_slots.items() 
                                        if status == "available"), None)
                    if available_slot:
                        book_slot_from_sensor(available_slot)
                    else:
                        print("No available slots!")
                elif user_response[-1] == "n":
                    print("No detected! No action taken.")
                elif user_response[-1] == "f":
                    print("Free command detected! Which slot to free? (1-4)")
                    # Wait for slot number input
                    user_response.clear()
                    while not user_response or user_response[-1] not in ["1", "2", "3", "4"]:
                        time.sleep(0.1)
                    slot_to_free = f"slot{user_response[-1]}"
                    free_slot_from_sensor(slot_to_free)
            elif distance > 100:
                print(f"Distance: {distance} cm - No Object Detected")
                GPIO.output(RELAY_PIN, GPIO.HIGH)  # Relay ON
            else:
                print("Out of Range")
    except KeyboardInterrupt:
        print("Exiting program...")
        GPIO.cleanup()

if __name__ == "__main__":
    # Start Flask server in a separate thread
    flask_thread = Thread(target=lambda: app.run(host="0.0.0.0", port=5000, debug=False))
    flask_thread.daemon = True
    flask_thread.start()
    
    # Start sensor loop in the main thread
    sensor_loop()
