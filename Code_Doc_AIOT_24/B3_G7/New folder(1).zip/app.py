import time
import requests
import RPi.GPIO as GPIO
import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008
import Adafruit_DHT
from flask import Flask, render_template, jsonify

# ----------------- Configuration -----------------
# LCD and Buzzer setup (same as before)
LCD_RS = 15
LCD_E = 12
LCD_D4 = 23
LCD_D5 = 21
LCD_D6 = 19
LCD_D7 = 24
BUZZER_PIN = 16
GAS_THRESHOLD = 100

# Sensor configuration
SPI_PORT = 0
SPI_DEVICE = 0
mcp = Adafruit_MCP3008.MCP3008(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))
DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 4

# ThingSpeak API
THINGSPEAK_API_KEY = "UYVY2NKYTNQP0KY7"
THINGSPEAK_URL = "https://api.thingspeak.com/update"

app = Flask(__name__)

# ----------------- Sensor Reading Functions -----------------
def read_sensors():
    # Gas Sensor
    gas_value = mcp.read_adc(0)
    
    # DHT11 Sensor
    humidity, temperature = Adafruit_DHT.read_retry(DHT_SENSOR, DHT_PIN)

    # If valid readings from DHT11 sensor, return the values
    if humidity is not None and temperature is not None:
        return temperature, humidity, gas_value
    else:
        return None, None, gas_value

# ----------------- Function to Upload Data to ThingSpeak -----------------
def send_to_thingspeak(temperature, humidity, gas_value):
    data = {
        'api_key': THINGSPEAK_API_KEY,
        'field1': temperature,
        'field2': humidity,
        'field3': gas_value,
    }
    try:
        response = requests.post(THINGSPEAK_URL, data=data)
        if response.status_code == 200:
            print("Data sent to ThingSpeak successfully")
        else:
            print("Failed to send data to ThingSpeak. HTTP Code:", response.status_code)
    except Exception as e:
        print("Error while sending data to ThingSpeak:", e)

# ----------------- Flask Routes -----------------
@app.route('/')
def index():
    # Read sensors' data
    temperature, humidity, gas_value = read_sensors()
    if temperature is None or humidity is None:
        temperature, humidity = "N/A", "N/A"

    # Send data to ThingSpeak
    send_to_thingspeak(temperature, humidity, gas_value)
    
    # Render the data to the webpage
    return render_template('index.html', temperature=temperature, humidity=humidity, gas_value=gas_value)

@app.route('/api/data')
def api_data():
    # Read sensors' data
    temperature, humidity, gas_value = read_sensors()
    if temperature is None or humidity is None:
        temperature, humidity = "N/A", "N/A"
    
    # Return data as JSON for API requests
    return jsonify({
        'temperature': temperature,
        'humidity': humidity,
        'gas_value': gas_value
    })

if __name__ == '__main__':
    app.run(debug=True)
