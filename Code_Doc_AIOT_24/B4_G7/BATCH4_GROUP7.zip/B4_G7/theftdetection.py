import requests
import Adafruit_DHT
import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008
import RPi.GPIO as gpio
import time

# ThingSpeak Configuration
THINGSPEAK_URL = "https://api.thingspeak.com/update"
API_KEY = "I95FJNB5BR629S5E"  # Replace with your actual Write API key
sensor = Adafruit_DHT.DHT11
pin = 4

# Light Sensor (LDR) Pin
LDR_PIN = 33  # Replace with your GPIO pin number for the LDR
BUZZER = 20   # Buzzer pin

# Ultrasonic sensor setup
TRIG = 19
ECHO = 26

# LED setup
LED = 2

# GPIO setup
gpio.setwarnings(False)
gpio.setmode(gpio.BCM)

# Setup Light Sensor pin
gpio.setup(LDR_PIN, gpio.IN)  # Light sensor pin as input
gpio.setup(BUZZER, gpio.OUT)  # Buzzer pin as output
gpio.setup(TRIG, gpio.OUT)    # Ultrasonic Trigger pin
gpio.setup(ECHO, gpio.IN)     # Ultrasonic Echo pin
gpio.setup(LED, gpio.OUT)     # LED pin as output

# Initialize all outputs to OFF
gpio.output(TRIG, False)
gpio.output(BUZZER, gpio.LOW)
gpio.output(LED, gpio.LOW)

# Function to measure distance using ultrasonic sensor
def measure_distance():
    gpio.output(TRIG, True)
    time.sleep(0.00001)
    gpio.output(TRIG, False)
    while gpio.input(ECHO) == 0:
        pulse_start = time.time()
    while gpio.input(ECHO) == 1:
        pulse_end = time.time()
    pulse_duration = pulse_end - pulse_start
    distance = round(pulse_duration * 17150, 2)
    print(f"Distance: {distance} cm")
    return distance

# Function to send data to ThingSpeak
def send_to_thingspeak(humidity, temperature, light_status, distance):
    payload = {
        "api_key": API_KEY,
        "field1": humidity,        # Humidity data
        "field2": temperature,     # Temperature data
        "field3": light_status,    # Light sensor status (0 or 1)
        "field4": distance         # Ultrasonic sensor distance
    }
    response = requests.post(THINGSPEAK_URL, data=payload)
    if response.status_code == 200:
        print(f"Data sent to ThingSpeak: {response.text}")
    else:
        print(f"Failed to send data to ThingSpeak: {response.status_code}")

# Main loop with ThingSpeak integration
try:
    print("Monitoring sensors...")

    while True:
        # Read humidity and temperature
        humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)
        if humidity is not None and temperature is not None:
            print(f"Humidity: {humidity}%, Temperature: {temperature}°C")
        else:
            print("Failed to retrieve temperature and humidity data.")

        # Read light sensor status
        light_status = gpio.input(LDR_PIN)
        if light_status == 0:  # 0 indicates dark
            print("Dark detected: Turning Buzzer ON")
            gpio.output(BUZZER, gpio.HIGH)
        else:  # 1 indicates normal light condition
            print("Normal light condition: Turning Buzzer OFF")
            gpio.output(BUZZER, gpio.LOW)

        # Measure distance using ultrasonic sensor
        distance = measure_distance()

        # Send data to ThingSpeak
        send_to_thingspeak(humidity, temperature, light_status, distance)

        # Check ultrasonic sensor condition
        if 2 < distance < 50:  # Threshold for object detection
            print("Object detected! Activating LED and Buzzer.")
            gpio.output(BUZZER, gpio.HIGH)
            gpio.output(LED, gpio.HIGH)
            time.sleep(0.5)
            gpio.output(BUZZER, gpio.LOW)
            gpio.output(LED, gpio.LOW)
        else:
            gpio.output(BUZZER, gpio.LOW)
            gpio.output(LED, gpio.LOW)

        time.sleep(0.5)

except KeyboardInterrupt:
    print("Program stopped by user.")
    gpio.cleanup()  # Clean up GPIO settings before exit
