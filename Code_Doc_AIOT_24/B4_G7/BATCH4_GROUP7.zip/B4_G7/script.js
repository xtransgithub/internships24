const CHANNEL_ID = '2776139'; // Replace with your channel ID
const READ_API_KEY = 'O8R9YE1460LL3B2D'; // Replace with your Read API Key
const RESULTS = 10; // Number of results to fetch

const url = `https://api.thingspeak.com/channels/${CHANNEL_ID}/feeds.json?api_key=${READ_API_KEY}&results=${RESULTS}`;

async function fetchThingSpeakData() {
    try {
        const response = await fetch(url);
        const data = await response.json();
        const feeds = data.feeds;

        // Reference to the table body
        const tableBody = document.getElementById('sensor-data');
        tableBody.innerHTML = ''; // Clear any existing rows

        // Populate table with data
        feeds.forEach(feed => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${feed.created_at}</td>
                <td>${feed.field2}</td>  <!-- Temperature -->
                <td>${feed.field1}</td>  <!-- Humidity -->
                <td>${feed.field3}</td>  <!-- Light Status -->
                <td>${feed.field4}</td>  <!-- Distance -->
            `;
            tableBody.appendChild(row);
        });
    } catch (error) {
        console.error('Error fetching data from ThingSpeak:', error);
    }
}

// Fetch data when the page loads
fetchThingSpeakData();
