import smtplib
import RPi.GPIO as GPIO
import Adafruit_DHT 
from Adafruit_DHT import read_retry, DHT11
import time
from datetime import datetime, timedelta


# Define pins for light sensor, ultrasonic sensor, LEDs, and DHT11
light_sensor_pin = 13
trig_pin = 19
echo_pin = 26
led_pin_1 = 18  # First streetlight
led_pin_2 = 12  # Second streetlight
led_pin_3 = 3   # Third streetlight
led_pin_4 = 5   # Fourth streetlight
dht_pin = 4     # Pin connected to DHT11 data

# Set up GPIO pins
GPIO.setmode(GPIO.BCM)
GPIO.setup(light_sensor_pin, GPIO.IN)
GPIO.setup(trig_pin, GPIO.OUT)
GPIO.setup(echo_pin, GPIO.IN)
GPIO.setup(led_pin_1, GPIO.OUT)
GPIO.setup(led_pin_2, GPIO.OUT)
GPIO.setup(led_pin_3, GPIO.OUT)
GPIO.setup(led_pin_4, GPIO.OUT)

# Define the DHT sensor type
DHT_SENSOR = Adafruit_DHT.DHT11

# Define functions for reading light sensor, measuring distance, and reading humidity
def read_light():
    light_state = GPIO.input(light_sensor_pin)
    return light_state

def measure_distance():
    # Trigger ultrasonic sensor
    GPIO.output(trig_pin, GPIO.LOW)
    time.sleep(0.00001)
    GPIO.output(trig_pin, GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(trig_pin, GPIO.LOW)

    # Measure pulse duration
    pulse_start = time.time()
    while GPIO.input(echo_pin) == 0:
        pulse_start = time.time()

    pulse_end = time.time()
    while GPIO.input(echo_pin) == 1:
        pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start

    # Calculate distance
    distance = pulse_duration * 17150
    distance = round(distance, 2)

    return distance

def read_humidity():
    humidity, temperature = Adafruit_DHT.read(DHT_SENSOR, dht_pin)
    return humidity

# Function to check if the current time is within the on/off schedule for a specific streetlight
def check_light_schedule(turn_on_time, turn_off_time):
    current_time = datetime.now().time()
    if turn_on_time < turn_off_time:  # No crossing midnight
        return turn_on_time <= current_time < turn_off_time
    else:  # Handle schedule that crosses midnight
        return current_time >= turn_on_time or current_time < turn_off_time

# Function to send email alerts
def send_email_alert(subject, body):
    sender_email = "surajnaidu73@gmail.com"
    password = "kfzzgiogrcylptcw"
    receiver_email = "1825mahalakshmi@gmail.com"
    

    try:
        with smtplib.SMTP("smtp.gmail.com", 587) as server:
            server.starttls()
            server.login(sender_email, password)
            message = f"Subject: {subject}\n\n{body}"
            server.sendmail(sender_email, receiver_email, message)
        print("Alert email sent successfully!")
    except Exception as e:
        print("Failed to send email alert:", e)

# Alert function for non-responsive lights
def check_light_status(led_pin, light_name):
    if not GPIO.input(led_pin):  # Check if the LED is OFF
        alert_message = f"ALERT: {light_name} is not responding and did not turn ON as scheduled."
        print(alert_message)
        # Send email alert
        send_email_alert(f"{light_name} Alert", alert_message)

# Main program loop
while True:
    # Define the on/off schedule times for each LED (streetlight)
    turn_on_time_1 = datetime.strptime('10:28', '%H:%M').time()
    turn_off_time_1 = datetime.strptime('10:29', '%H:%M').time()

    turn_on_time_2 = datetime.strptime('10:36', '%H:%M').time()
    turn_off_time_2 = datetime.strptime('10:37', '%H:%M').time()

    turn_on_time_3 = datetime.strptime('12:45', '%H:%M').time()
    turn_off_time_3 = datetime.strptime('12:46', '%H:%M').time()

    turn_on_time_4 = datetime.strptime('12:45', '%H:%M').time()
    turn_off_time_4 = datetime.strptime('12:46', '%H:%M').time()

    light_state = read_light()
    distance = measure_distance()
    humidity = read_humidity()

    # Ensure all lights are initially OFF at the start
    GPIO.output(led_pin_1, GPIO.LOW)
    GPIO.output(led_pin_2, GPIO.LOW)
    GPIO.output(led_pin_3, GPIO.LOW)
    GPIO.output(led_pin_4, GPIO.LOW)

    # Check if it's time to turn on or off each LED (streetlight) based on the schedule
    if check_light_schedule(turn_on_time_1, turn_off_time_1):
        GPIO.output(led_pin_1, GPIO.HIGH)  # Turn on LED 1
        print("Streetlight 1 ON (Based on time schedule)")
    else:
        GPIO.output(led_pin_1, GPIO.LOW)  # Turn off LED 1
        print("Streetlight 1 OFF (Based on time schedule)")
        check_light_status(led_pin_1, "Streetlight 1")  # Check status and alert

    if check_light_schedule(turn_on_time_2, turn_off_time_2):
        GPIO.output(led_pin_2, GPIO.HIGH)  # Turn on LED 2
        print("Streetlight 2 ON (Based on time schedule)")
    else:
        GPIO.output(led_pin_2, GPIO.LOW)  # Turn off LED 2
        print("Streetlight 2 OFF (Based on time schedule)")
        check_light_status(led_pin_2, "Streetlight 2")  # Check status and alert

    if check_light_schedule(turn_on_time_3, turn_off_time_3):
        GPIO.output(led_pin_3, GPIO.HIGH)  # Turn on LED 3
        print("Streetlight 3 ON (Based on time schedule)")
    else:
        GPIO.output(led_pin_3, GPIO.LOW)  # Turn off LED 3
        print("Streetlight 3 OFF (Based on time schedule)")
        check_light_status(led_pin_3, "Streetlight 3")  # Check status and alert

    if check_light_schedule(turn_on_time_4, turn_off_time_4):
        GPIO.output(led_pin_4, GPIO.HIGH)  # Turn on LED 4
        print("Streetlight 4 ON (Based on time schedule)")
    else:
        GPIO.output(led_pin_4, GPIO.LOW)  # Turn off LED 4
        print("Streetlight 4 OFF (Based on time schedule)")
        check_light_status(led_pin_4, "Streetlight 4")  # Check status and alert
    
    if humidity is not None:
        print("Humidity:", humidity, "%")
    else:
        print("Failed to retrieve humidity data")

    # Control LED 1 based on light sensor and distance
    if light_state == 0:  # Light sensor triggered (dark)
        print("Light ON")
        # Turn on LED 1 if distance is within range and humidity is low
        if distance > 2 and distance < 400 and (humidity is not None and humidity < 100):
            GPIO.output(led_pin_1, GPIO.HIGH)  # Turn ON LED 1
            print("Distance:", distance, "cm")
            print("Low Humidity: Turning LED ON")
        else:
            GPIO.output(led_pin_1, GPIO.LOW)  # Turn OFF LED 1
            print("Out of Range or Humidity Sufficient")
    else:
        print("Light Not Detected")
        GPIO.output(led_pin_1, GPIO.LOW)  # Turn OFF LED 1 if light is detected
        
    time.sleep(2)  # Delay for 2 seconds

# Clean up GPIO pins
GPIO.cleanup()
