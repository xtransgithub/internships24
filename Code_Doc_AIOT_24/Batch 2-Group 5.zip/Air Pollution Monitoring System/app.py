import Adafruit_GPIO.SPI as SPI
import Adafruit_MCP3008
import Adafruit_DHT
import RPi.GPIO as GPIO
from flask import Flask, render_template, jsonify
import time

# Flask app initialization
app = Flask(_name_)

# SPI port and device for MCP3008 ADC
SPI_PORT = 0
SPI_DEVICE = 0
mcp = Adafruit_MCP3008.MCP3008(spi=SPI.SpiDev(SPI_PORT, SPI_DEVICE))

# DHT11 sensor configuration
DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 4  # GPIO pin where the DHT11 sensor is connected

# Buzzer pin configuration
BUZZER_PIN = 17  # GPIO pin for buzzer (use the correct pin on your setup)

# Set up the GPIO for buzzer
GPIO.setmode(GPIO.BCM)
GPIO.setup(BUZZER_PIN, GPIO.OUT)

# Define threshold values for air quality
GOOD_AIR_THRESHOLD = 100  # Threshold for good air quality
BAD_AIR_THRESHOLD = 300  # Threshold for bad air quality

def classify_air_quality(value):
    """Classifies the air quality based on the sensor reading."""
    if value < GOOD_AIR_THRESHOLD:
        return "Good Air Quality"  # Clean air detected
    elif GOOD_AIR_THRESHOLD <= value < BAD_AIR_THRESHOLD:
        return "Moderate Air Quality"  # Moderate pollution detected
    else:
        return "Bad Air Quality"  # High pollution detected

def activate_buzzer(state):
    """Activates or deactivates the buzzer."""
    if state == "moderate" or state == "bad":
        GPIO.output(BUZZER_PIN, GPIO.HIGH)  # Turn on the buzzer
    else:
        GPIO.output(BUZZER_PIN, GPIO.LOW)  # Turn off the buzzer

@app.route('/')
def index():
    """Home route that displays the main page."""
    return render_template('index.html')

@app.route('/get_data')
def get_data():
    """Fetches air quality, temperature, and humidity data."""
    # Read the value from the gas sensor (MQ135) on channel 0
    gas_value = mcp.read_adc(0)
    
    # Classify the air quality
    air_quality = classify_air_quality(gas_value)
    
    # Detect and alert for bad or moderate air quality and activate the buzzer
    if air_quality == "Moderate Air Quality" or air_quality == "Bad Air Quality":
        activate_buzzer(air_quality.lower())
    else:
        activate_buzzer("good")
    
    # Read temperature and humidity from the DHT11 sensor
    humidity, temperature = Adafruit_DHT.read_retry(DHT_SENSOR, DHT_PIN)
    
    # Prepare response
    data = {
        'gas_value': gas_value,
        'air_quality': air_quality,
        'temperature': temperature,
        'humidity': humidity
    }
    
    return jsonify(data)

if _name_ == '_main_':
    app.run(host='0.0.0.0', port=5000, debug=True)
    GPIO.cleanup()