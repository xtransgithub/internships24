import RPi.GPIO as GPIO
import requests
import time
GPIO.setwarnings(False)
#pin config
TRIG = 19
ECHO = 26

#laptop url
LAPTOP_URL = "http://172.28.131.45:5000/trigger"

#setup
def setup_ultrasonic():
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(TRIG,GPIO.OUT)
    GPIO.setup(ECHO,GPIO.IN)
    GPIO.output(TRIG,False)
    print("Ultrasonic Sensor Initialized!")
    time.sleep(5)

def measure_distance():
    GPIO.output(TRIG,True)
    time.sleep(0.00001)
    GPIO.output(TRIG,False)
    pulse_end , pulse_start = 0 , 0
    while GPIO.input(ECHO)==0:               #Check whether the ECHO is LOW
        pulse_start = time.time()
    
    while GPIO.input(ECHO)==1:               #Check whether the ECHO is HIGH
        pulse_end = time.time() 

    pulse_duration = pulse_end - pulse_start
    distance = pulse_duration * 17150        #Multiply pulse duration by 17150 to get distance
    distance = round(distance, 2)
    return distance
    
def cleanup_ultrasonic():
    GPIO.cleanup()
    print("GPIO Cleaned Up!")
    
    
def send_trigger():
    try:
        response = requests.post(LAPTOP_URL , json = {"trigger":"motion_detected"})
        if response.status_code == 200:
            print("Trig send successfully")
        else:
            print("Failed trig!")
    except Exception as e:
        print(f"Error sending trigger {e}")
        

    
    
