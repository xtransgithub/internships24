import cv2

camera = cv2.VideoCapture(0)

if not camera.isOpened():
	print("Error:Cant open Camere")
else:
	print("Camera initialized")
	
ret, frame = camera.read()
if ret:
	cv2.imshow("Captured Frame", frame)
	cv2.waitKey(0)
else:
	print("Error: Could not capture frame.")
	
camera.release()
cv2.destroyAllWindows()
