from motion_detection import setup_ultrasonic , measure_distance , cleanup_ultrasonic , send_trigger
from cam_capture import camera_capture
import time

def main():
    try:
        setup_ultrasonic()
        
        while True:
            
            distance = measure_distance()
            print("Start motion detection through ultrasonic sensor...")
            print("Distance in cm : ", distance)
            if distance < 100:
                print("Motion Detected!")
                send_trigger()
                
            time.sleep(1)
                
            
    except KeyboardInterrupt:
        print("Interrupt")
    finally:
        cleanup_ultrasonic()

if __name__ == "__main__":
    main()

