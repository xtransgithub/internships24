from flask import Flask, request, render_template, Response
import cv2
import face_recognition
import numpy as np
import os
from twilio.rest import Client
import threading
import time
import queue

# Twilio account credentials (set these as environment variables for security)
TWILIO_ACCOUNT_SID = os.getenv('TWILIO_ACCOUNT_SID')  # Your Twilio Account SID
TWILIO_AUTH_TOKEN = os.getenv('TWILIO_AUTH_TOKEN')    # Your Twilio Auth Token
TWILIO_PHONE_NUMBER = os.getenv('TWILIO_PHONE_NUMBER')  # Your Twilio phone number
ALERT_PHONE_NUMBER = os.getenv('ALERT_PHONE_NUMBER')  # Recipient's phone number

app = Flask(__name__)

# Predefined known faces and their names
known_face_encodings = []
known_face_names = []

# Last alert time
last_alert_time = 0
alert_cooldown = 10  # seconds

# Queue to store log messages
log_queue = queue.Queue(maxsize=100)

# Global video capture object
global_video_capture = None

def add_log_message(message):
    """Add log message to the queue, removing oldest if full."""
    if log_queue.full():
        log_queue.get()
    log_queue.put(message)

def load_known_faces(faces_directory='./faces'):
    global known_face_encodings, known_face_names
    known_face_encodings = []
    known_face_names = []

    try:
        if not os.path.exists(faces_directory):
            raise FileNotFoundError(f"Directory {faces_directory} does not exist.")
        
        for filename in os.listdir(faces_directory):
            if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                try:
                    name = os.path.splitext(filename)[0]
                    image_path = os.path.join(faces_directory, filename)
                    image = face_recognition.load_image_file(image_path)
                    face_locations = face_recognition.face_locations(image)

                    if face_locations:
                        encodings = face_recognition.face_encodings(image, face_locations)
                        known_face_encodings.append(encodings[0])
                        known_face_names.append(name)
                        add_log_message(f"Loaded face for {name}")
                    else:
                        add_log_message(f"No face found in {filename}")
                except Exception as e:
                    add_log_message(f"Error processing {filename}: {e}")

        add_log_message(f"Total known faces loaded: {len(known_face_names)}")
    except Exception as e:
        add_log_message(f"Error loading known faces: {e}")

def alert_intruder(name):
    global last_alert_time
    current_time = time.time()

    if current_time - last_alert_time < alert_cooldown:
        add_log_message("Alert skipped: cooldown period active.")
        return

    last_alert_time = current_time

    try:
        client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
        message_body = f"ALERT! Unknown person detected: {name}." if name == "Unknown" else f"Person detected: {name}."
        
        message = client.messages.create(
            body=message_body,
            from_= TWILIO_PHONE_NUMBER,
            to= ALERT_PHONE_NUMBER
        )
        
        add_log_message(f"Alert sent! Message SID: {message.sid}")
    
    except Exception as e:
        add_log_message(f"Failed to send alert: {e}")

def generate_frames(tolerance=0.55):
    global global_video_capture
    
    if global_video_capture is None:
        global_video_capture = cv2.VideoCapture(0)
    
    if not global_video_capture.isOpened():
        add_log_message(f"Error: Could not access camera.")
        return

    while True:
        success, frame = global_video_capture.read()
        if not success:
            break

        # Process frame for face recognition
        small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)
        face_locations = face_recognition.face_locations(rgb_small_frame, model="hog")

        if face_locations:
            face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

            for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
                matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=tolerance)
                name = "Unknown"

                if True in matches:
                    match_indices = [i for i, match in enumerate(matches) if match]
                    matched_names = [known_face_names[i] for i in match_indices]
                    name = matched_names[0] if matched_names else "Unknown"
                
                if name == "Unknown":
                    alert_intruder(name)

                top *= 4
                right *= 4
                bottom *= 4
                left *= 4

                color = (0, 255, 0) if name != "Unknown" else (0, 0, 255)
                cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
                cv2.rectangle(frame, (left, bottom - 35), (right, bottom), color, cv2.FILLED)
                cv2.putText(frame, name, (left + 6, bottom - 6), cv2.FONT_HERSHEY_DUPLEX, 0.8, (255, 255, 255), 1)

        # Encode frame for streaming
        ret, buffer = cv2.imencode('.jpg', frame)
        frame_bytes = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

@app.route('/')
def index():
    """Render the main page with logs."""
    logs = list(log_queue.queue)
    return render_template('index.html', logs=logs)

@app.route('/video_feed')
def video_feed():
    """Video streaming route."""
    return Response(generate_frames(), 
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/trigger', methods=['POST'])
def handle_trigger():
    data = request.json
    if data.get("trigger") == "motion_detected":
        add_log_message("Motion detected trigger received!")
        return "Motion trigger received", 200
    return "Invalid request", 400

def cleanup():
    global global_video_capture
    if global_video_capture:
        global_video_capture.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    try:
        add_log_message("Loading known faces...")
        load_known_faces()
        add_log_message("Known faces loaded.")
        
        app.run(host="0.0.0.0", port=5000, debug=True)
    except Exception as e:
        add_log_message(f"An error occurred: {e}")
    finally:
        cleanup()