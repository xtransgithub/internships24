import RPi.GPIO as GPIO
import time
from datetime import datetime
import requests
from twilio.rest import Client

# Pin configuration (same as before)
LED_PIN_LDR = 4# GPIO pin connected to the LED for LDR
LIGHT_SENSOR_PIN = 33  # GPIO pin connected to the light sensor (digital output)
TRIG = 19  # GPIO pin connected to TRIG of the ultrasonic sensor
ECHO = 26  # GPIO pin connected to ECHO of the ultrasonic sensor
LED_PIN_ULTRASONIC = 3  # GPIO pin connected to the LED for Ultrasonic sensor
LED_PIN_TIME = [2, 3, 4]  # GPIO pin where the LED is connected for time-based control

# Threshold for ultrasonic sensor
DETECTION_THRESHOLD = 30
ON_TIME = "12:29"
OFF_TIME = "12:30"

# Twilio SMS Setup (Replace with your Twilio credentials)
ACCOUNT_SID = 'ACb92e2544dc1e85a37ea2fc385f01792e'
AUTH_TOKEN = 'e285537b00d952c75e07d027c1e0d55d'
TO_PHONE_NUMBER = '+917204393829'
FROM_PHONE_NUMBER = '+17752628454'

# easy_install twilio(Replace with your Pushover details)
PUSHOVER_USER_KEY = 'uazsnfabiyaqwkiftg6znkx5wzxtj9'
PUSHOVER_APP_TOKEN = 'at5wjuvo2i7qom83zu55jyxkw81zwf'
PUSHOVER_URL = "https://api.pushover.net/1/messages.json"

# Setup GPIO mode
GPIO.setmode(GPIO.BCM)
GPIO.setup(LED_PIN_LDR, GPIO.OUT)
GPIO.setup(LIGHT_SENSOR_PIN, GPIO.IN)
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
GPIO.setup(LED_PIN_ULTRASONIC, GPIO.OUT, initial=GPIO.LOW)
GPIO.setup(LED_PIN_TIME, GPIO.OUT)

# Function to send SMS using Twilio
def send_sms(message):
    client = Client(ACCOUNT_SID, AUTH_TOKEN)
    message = client.messages.create(
        body=message,
        from_=FROM_PHONE_NUMBER,
        to=TO_PHONE_NUMBER
    )
    print(f"SMS sent: {message.sid}")

# Function to send Push Notification using Pushover
def send_push_notification(message):
    data = {
        'token': PUSHOVER_APP_TOKEN,
        'user': PUSHOVER_USER_KEY,
        'message': message
    }
    response = requests.post(PUSHOVER_URL, data=data)
    if response.status_code == 200:
        print("Push Notification sent.")
    else:
        print("Failed to send Push Notification.")

# Function to control the LED based on the LDR sensor
def ldr_control():
    try:
        light_level = GPIO.input(LIGHT_SENSOR_PIN)  # Read light sensor (0 for dark, 1 for bright)
        if light_level == 1:  # Dark environment
            GPIO.output(LED_PIN_LDR, GPIO.HIGH)  # Turn LED ON
            print("Dark: LED ON")
        else:  # Bright environment
            GPIO.output(LED_PIN_LDR, GPIO.LOW)  # Turn LED OFF
            print("Bright: LED OFF")
    except Exception as e:
        print(f"Error in LDR control: {e}")
        send_sms("Fault in LDR Sensor!")
        send_push_notification("Fault in LDR Sensor!")

# Function to control the LED based on ultrasonic sensor distance
def ultrasonic_control():
    try:
        GPIO.output(TRIG, False)
        time.sleep(2)  # Allow sensor to stabilize

        # Trigger a pulse
        GPIO.output(TRIG, True)
        time.sleep(0.00001)  # 10 microseconds
        GPIO.output(TRIG, False)

        # Measure the time for the pulse to return
        while GPIO.input(ECHO) == 0:
            pulse_start = time.time()

        while GPIO.input(ECHO) == 1:
            pulse_end = time.time()

        # Calculate distance
        pulse_duration = pulse_end - pulse_start
        distance = pulse_duration * 17150  # Convert time to distance in cm
        distance = round(distance, 2)  # Round to two decimal places

        if 2 < distance < 400:  # Valid range of sensor
            print(f"Distance: {distance} cm")
            if distance <= DETECTION_THRESHOLD:  # Object detected
                GPIO.output(LED_PIN_ULTRASONIC, GPIO.HIGH)  # Turn on the LED
                print("Object detected! LED ON")
                send_sms("OBJECT DETECTED THROUGH ULTRASONIC SENSOR:- LED ON")
                send_push_notification("OBJECT DETECTED THROUGH ULTRASONIC SENSOR:- LED ON")
            else:
                GPIO.output(LED_PIN_ULTRASONIC, GPIO.LOW)  # Turn off the LED
        else:
            print("Out of Range")
            send_sms("Ultrasonic Sensor is out of range!")
            send_push_notification("Ultrasonic Sensor is out of range!")
    except Exception as e:
        print(f"Error in Ultrasonic control: {e}")
        send_sms("Fault in Ultrasonic Sensor!")
        send_push_notification("Fault in Ultrasonic Sensor!")

# Function to control the LED based on time
def time_based_control(on_time, off_time):
    try:
        current_time = datetime.now().strftime('%H:%M')  # Current time in hours:minutes format
        print(f"Current time: {current_time}")
        
        if current_time == on_time:
            GPIO.output(LED_PIN_TIME, GPIO.HIGH)  # Turn the LED on
            print(f"LED is ON at {on_time}")
            send_sms(f"LED SWITCHED ON AT{on_time}")
            send_push_notification(f"LED SWITCHED ON AT{on_time}")
        elif current_time == off_time:
            GPIO.output(LED_PIN_TIME, GPIO.LOW)  # Turn the LED off
            print(f"LED is OFF at {off_time}")
            send_sms(f"LED SWITCHED OFF AT{off_time}")
            send_push_notification(f"LED SWITCHED OFF AT{off_time}")
    except Exception as e:
        print(f"Error in Time-based control: {e}")
        send_sms("Fault in Time-based Control!")
        send_push_notification("Fault in Time-based Control!")

# Main loop to monitor and control
try:
    while True:
        # Call each function to control LEDs
        ldr_control()
        ultrasonic_control()
        time_based_control(ON_TIME, OFF_TIME)
        
        time.sleep(1)  # Delay to avoid high CPU usage

except KeyboardInterrupt:
    print("Program interrupted by user.")
finally:
    GPIO.cleanup()  # Clean up GPIO to reset pin states
    print("GPIO cleanup complete.")
