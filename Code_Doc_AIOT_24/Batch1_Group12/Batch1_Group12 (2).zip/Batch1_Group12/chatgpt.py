import RPi.GPIO as GPIO
import time
import pyqrcode
from PIL import Image  # Import Pillow to display the image

# GPIO Pin Setup
# Stepper Motor Pins
IN1 = 13  # GPIO pin for IN1
IN2 = 4   # GPIO pin for IN2
IN3 = 6   # GPIO pin for IN3
IN4 = 5   # GPIO pin for IN4

# Ultrasonic Sensor Pins
TRIG = 19  # Trigger Pin
ECHO = 26  # Echo Pin

# LED and Switch Pins
led3 = 3
led4 = 5
switch3 = 21
switch2 = 20  # Emergency switch

# Motor Sequence for Stepper Motor
motor_sequence = [
    [1, 0, 0, 1],
    [1, 0, 0, 0],
    [1, 1, 0, 0],
    [0, 1, 0, 0],
    [0, 1, 1, 0],
    [0, 0, 1, 0],
    [0, 0, 1, 1],
    [0, 0, 0, 1]
]

# GPIO Initialization
GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

# Stepper Motor Setup
GPIO.setup(IN1, GPIO.OUT)
GPIO.setup(IN2, GPIO.OUT)
GPIO.setup(IN3, GPIO.OUT)
GPIO.setup(IN4, GPIO.OUT)

# Ultrasonic Sensor Setup
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

# LED and Switch Setup
GPIO.setup(led3, GPIO.OUT, initial=0)
GPIO.setup(led4, GPIO.OUT, initial=0)
GPIO.setup(switch3, GPIO.IN)
GPIO.setup(switch2, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # Pull-up resistor for switch2

# Function to Rotate Motor
def rotate_motor(steps, direction):
    if direction == "clockwise":
        step_order = motor_sequence
    else:
        step_order = motor_sequence[::-1]

    for _ in range(steps):
        for step in step_order:
            GPIO.output(IN1, step[0])
            GPIO.output(IN2, step[1])
            GPIO.output(IN3, step[2])
            GPIO.output(IN4, step[3])
            time.sleep(0.002)  # Adjust speed here

# Function to Measure Distance
def measure_distance():
    GPIO.output(TRIG, True)
    time.sleep(0.00001)  # 10µs pulse
    GPIO.output(TRIG, False)

    while GPIO.input(ECHO) == 0:
        start_time = time.time()
    while GPIO.input(ECHO) == 1:
        end_time = time.time()

    duration = end_time - start_time
    distance = (duration * 34300) / 2  # Speed of sound: 34300 cm/s
    return distance

# Function to generate QR Code and display it
def generate_and_display_qr_code(data):
    # Generate QR code
    qr = pyqrcode.create(data)
    
    # Save the QR code to a PNG file temporarily
    qr_path = "/home/pi/my_qr_code.png"
    qr.png(qr_path, scale=6)  # Save as PNG

    # Open the saved QR code PNG file using Pillow
    img = Image.open(qr_path)

    # Display the image using Pillow
    img.show()

# Simulate checking if the Google Form is filled (in real implementation, use API or database)
def is_form_filled():
    # Simulate checking form submission using user input
    input("Press Enter after filling out the form to proceed...")
    return True

try:
    qr_code_scanned = False  # Flag to track if QR code is scanned and form is filled

    while True:
        # Regular distance-based operation
        print("Measuring distance...")
        distance = measure_distance()
        print(f"Distance: {distance:.2f} cm")

        # Object detected within the range
        if distance < 50:  # Trigger door opening if distance is less than 50 cm
            print("Object detected! Generating QR code...")
            
            # Generate the QR code with the Google Form link
            generate_and_display_qr_code("https://forms.gle/uKZVtpDedhJitpti6")
            qr_code_scanned = False  # Reset flag for QR scan check

            # Simulate waiting for the form to be filled out
            print("Waiting for the form to be filled...")
            if is_form_filled():  # Simulate waiting for form submission
                qr_code_scanned = True  # Form is filled, QR code is scanned
                print("Form filled!")

        # Proceed to motor control only if QR code has been scanned and form is filled
        if qr_code_scanned:  # Check if the QR code was scanned and form filled
            print("QR code scanned and form filled, activating motor...")
            GPIO.output(led3, True)
            GPIO.output(led4, False)
            rotate_motor(26, "clockwise")
            time.sleep(2)  # Keep the door open for 2 seconds
            print("Closing door...")
            GPIO.output(led3, False)
            GPIO.output(led4, True)
            rotate_motor(26, "counterclockwise")
            time.sleep(1)
            qr_code_scanned = False  # Reset flag after the door is closed

        # Check if the emergency switch is pressed
        if GPIO.input(switch2) == GPIO.LOW:  # Assuming LOW is pressed
            print("Emergency! Opening door...")
            GPIO.output(led3, True)
            GPIO.output(led4, False)
            rotate_motor(26, "clockwise")
            time.sleep(5)  # Keep the door open
            print("Closing door...")
            GPIO.output(led3, False)
            GPIO.output(led4, True)
            rotate_motor(26, "counterclockwise")
            time.sleep(1)
            continue

        time.sleep(0.5)  # Delay before next measurement

except KeyboardInterrupt:
    print("Program stopped")

finally:
    GPIO.cleanup()
