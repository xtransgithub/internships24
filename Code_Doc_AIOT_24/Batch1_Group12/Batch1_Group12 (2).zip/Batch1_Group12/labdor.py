import os.path
import pickle
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

# The scope required for accessing and modifying the Google Sheet
SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']

# The ID of your spreadsheet and the range (you can specify 'LabDoor' as the sheet name)
SPREADSHEET_ID = '194576122956-i53pjafq129un2jct0j68p9aguakkdej.apps.googleusercontent.com'  # Your spreadsheet ID
SHEET_NAME = 'LabDoor'

# The range you will read from, assuming you are reading all rows in 'LabDoor' sheet
RANGE_NAME = f'{SHEET_NAME}!A:Z'  # Read all columns from A to Z

def get_credentials():
    """Gets valid credentials from storage."""
    creds = None
    # If there are no (valid) credentials available, let the user log in.
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    # If credentials are expired or invalid, allow the user to login again
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        
        # Save the credentials for future use
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    
    return creds

def get_last_row_of_sheet():
    """Get the last row from the 'LabDoor' sheet."""
    creds = get_credentials()

    # Build the service to interact with the Sheets API
    service = build('sheets', 'v4', credentials=creds)

    # Fetch the sheet values
    sheet = service.spreadsheets()
    result = sheet.values().get(spreadsheetId=SPREADSHEET_ID, range=RANGE_NAME).execute()

    # Get the data
    values = result.get('values', [])

    if not values:
        print('No data found.')
        return None
    else:
        # Last row will be the last item in the list of rows
        last_row = values[-1]  # Get the last row of data
        print('Last row:', last_row)
        return last_row

if __name__ == '__main__':
    last_row = get_last_row_of_sheet()
    if last_row:
        # You can process the last row here if needed
        print(f"Last row data: {last_row}")
