import time
import RPi.GPIO as GPIO
import Adafruit_DHT
from Adafruit_MCP3008 import MCP3008
from twilio.rest import Client
import requests
import smtplib
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import re
from flask import jsonify

# Setup Flask
app = Flask(__name__)
app.secret_key = 'your_secret_key'  # For session management
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'  # Database URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# GPIO setup
GPIO.setmode(GPIO.BCM)

# DHT11 sensor
DHT_PIN = 4  # GPIO pin for DHT11 sensor

# Gas sensor (MQ2) using MCP3008
CS_PIN = 8  # Chip select pin for MCP3008
mcp = MCP3008(clk=11, cs=CS_PIN, miso=9, mosi=10)

# Buzzer & LED
BUZZER_PIN = 20
LED_PIN = 18
GPIO.setup(BUZZER_PIN, GPIO.OUT,initial=GPIO.LOW)
GPIO.setup(LED_PIN, GPIO.OUT,initial=GPIO.LOW)

# ThingSpeak Setup
THINGSPEAK_API_KEY = 'Your_thingspeak_api key'  # add your Your_thingspeak_api key
THINGSPEAK_URL = 'https://api.thingspeak.com/update.json'

# Twilio Setup
TWILIO_PHONE_NUMBER = 'Your Twilio phone number'  # Your Twilio phone number
TWILIO_SID = 'Your Twilio SID' #Your Twilio SID
TWILIO_AUTH_TOKEN = 'Your Twilio auth token' #Your Twilio auth token

client = Client(TWILIO_SID, TWILIO_AUTH_TOKEN)

# Send SMS notification via Twilio to logged-in user
def send_sms_alert(user_phone_number, message):
    client.messages.create(
        body=message,
        from_=TWILIO_PHONE_NUMBER,
        to=user_phone_number
    )
    print(f"SMS sent to {user_phone_number}: {message}")

# Send data to ThingSpeak
def send_to_thingspeak(temperature, humidity, gas_level):
    payload = {
        'api_key': THINGSPEAK_API_KEY,
        'field1': temperature,
        'field2': humidity,
        'field3': gas_level
    }
    response = requests.post(THINGSPEAK_URL, data=payload)
    return response.status_code

previous_temperature = None
previous_gas_level = None

# Get sensor readings
def get_sensor_data():
    global previous_temperature, previous_gas_level

    # DHT11 temperature and humidity
    humidity, temperature = Adafruit_DHT.read_retry(Adafruit_DHT.DHT11, DHT_PIN)

    # MQ2 Gas sensor (via MCP3008)
    gas_level = mcp.read_adc(0)  # Reading ADC channel 0

    # Detect sudden changes in temperature
    sudden_temp_change = False
    if previous_temperature is not None and temperature is not None:
        if abs(temperature - previous_temperature) >= 5:  # Sudden change threshold for temperature
            sudden_temp_change = True

    # Detect sudden changes in gas level
    sudden_gas_change = False
    if previous_gas_level is not None:
        if abs(gas_level - previous_gas_level) >= 50:  # Sudden change threshold for gas level
            sudden_gas_change = True

    # Update previous values
    previous_temperature = temperature
    previous_gas_level = gas_level

    # Action for sudden temperature change
    if sudden_temp_change:
        GPIO.output(BUZZER_PIN, GPIO.HIGH)  # Turn on buzzer
        print(f"Sudden Temperature Change Detected! Current Temperature: {temperature}°C")
        time.sleep(5)  # Buzzer remains on for 5 seconds
        GPIO.output(BUZZER_PIN, GPIO.LOW)  # Turn off buzzer
        if 'user_email' in session:
            user = User.query.filter_by(email=session['user_email']).first()
            if user and user.phone_number:
                send_sms_alert(user.phone_number, f"Sudden Temperature Change! Current Temperature: {temperature}°C.")

    # Action for sudden gas level change
    if sudden_gas_change:
        GPIO.output(LED_PIN, GPIO.HIGH)  # Turn on LED (pin 18)
        print(f"Sudden Gas Level Change Detected! Current Gas Level: {gas_level}")
        time.sleep(5)  # LED remains on for 5 seconds
        GPIO.output(LED_PIN, GPIO.LOW)  # Turn off LED
        if 'user_email' in session:
            user = User.query.filter_by(email=session['user_email']).first()
            if user and user.phone_number:
                send_sms_alert(user.phone_number, f"Sudden Gas Change! Current Gas Level: {gas_level}.")

    return temperature, humidity, gas_level

# Define the User database model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    phone_number = db.Column(db.String(15), nullable=False)  # Store user's phone number

# Initialize database tables if not already created
with app.app_context():
    db.create_all()

# Signup route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        phone_number = request.form['phone_number']

        # Ensure phone number starts with +91
        if not phone_number.startswith('+91'):
            phone_number = '+91' + phone_number.lstrip('+')  # Add +91 if missing

        # Validate the phone number format (to ensure it has the correct number of digits)
        if not re.match(r"^\+91\d{10}$", phone_number):
            flash("Invalid phone number format. Ensure it is in the format: +91XXXXXXXXXX")
            return redirect(url_for('signup'))

        # Hash the password before saving to the database
        hashed_password = generate_password_hash(password)

        # Add the phone number to the database
        new_user = User(email=email, password=hashed_password, phone_number=phone_number)
        db.session.add(new_user)
        db.session.commit()

        flash("Signup successful!")
        return redirect(url_for('login'))
    
    return render_template('signup.html')


@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            session['user_email'] = user.email
            flash("Login successful!", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid email or password!", "danger")

    return render_template('login.html')


# Dashboard route
@app.route('/dashboard')
def dashboard():
    if 'user_email' in session:
        # Fetch the user from the database using the email stored in session
        user = User.query.filter_by(email=session['user_email']).first()
        
        if user:
            # Get sensor data and send to ThingSpeak
            temperature, humidity, gas_level = get_sensor_data()
            send_to_thingspeak(temperature, humidity, gas_level)
            
            # Render the dashboard page and pass the user object along with sensor data
            return render_template(
                'dashboard.html',
                temperature=temperature,
                humidity=humidity,
                gas_level=gas_level,
                user=user  # Pass user object to the template
            )
        else:
            flash("User not found.", "danger")
            return redirect(url_for('login'))
    else:
        flash("You must be logged in to access the dashboard.", "danger")
        return redirect(url_for('login'))


@app.route('/logout')
def logout():
    session.pop('user_email', None)  # Remove the user's email from the session
    flash("You have been logged out.", "success")
    return redirect(url_for('login'))  # Redirect to login page after logging out

    
# Route to get sensor data as JSON
@app.route('/get_sensor_data')
def get_sensor_data_ajax():
    # Get the latest sensor data
    temperature, humidity, gas_level = get_sensor_data()

    # Return data as JSON
    return jsonify({
        'temperature': temperature,
        'humidity': humidity,
        'gas_level': gas_level
    })


if __name__ == '__main__':
    try:
        app.run(host='0.0.0.0', port=5000, debug=True)
    except KeyboardInterrupt:
        pass
    finally:
        GPIO.cleanup()
